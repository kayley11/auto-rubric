"""Grade new fixed Gemma answers with the saved full rubric and scope audit."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import deepcopy
import fcntl
import importlib.util
import json
from pathlib import Path
import re
import time

import prepare_inputs
import recovery_core as core
import run_generate

ROOT, RUNS = core.ROOT, core.ROOT.parent
CRITERIA = {c["id"]: c for c in core.read(ROOT / "sources/FULL_RUBRIC.json")["criteria"]}
spec = importlib.util.spec_from_file_location("retained_full22_grading_definitions", RUNS / "full_rubric_completion_78_20261104/complete.py")
OLD = importlib.util.module_from_spec(spec)
spec.loader.exec_module(OLD)


def prepare_plans():
    index = prepare_inputs.verify()
    audit = core.read(RUNS / "na_scope_audit_135_20261112/CASE_ITEM_AUDIT.json")
    core.freeze("sources/scoring/CASE_ITEM_AUDIT.json", audit)
    audit = {(r["case_id"], r["item"]): r for r in audit}
    for entry in index["cases"]:
        cid = entry["case_id"]
        packet = core.read(ROOT / entry["researcher_case_file"])
        if entry["cohort"] != "complex57":
            packet = next(c for c in packet if c["id"] == cid)
            plan = core.read(RUNS / "full_rubric_completion_78_20261104/applicability" / (entry["cohort"] + "__" + cid + ".json"))
            core.freeze("sources/scoring/original_plans/" + cid + ".json", plan)
            source_scope = {r["item"]: {"in_scope": r["applicability"] == "applicable", "reason": r["reason"]} for r in plan["items"]}
            requirements = plan["candidate_requirements"]
            mode = plan["d5c_mode"]
        else:
            source_scope = packet["scope"]
            requirements = [{**r, "id": "R" + str(n)} for n, r in enumerate(packet["requirements"], 1)]
            mode = "planning_only"
        scope = {}
        for item, rule in source_scope.items():
            check = audit.get((cid, item))
            if check and check["classification"] == "awaiting_confirmation":
                status = "applicability_pending"
                reason = check["reason"] + (" Decision needed: " + check["decision_needed"] if check.get("decision_needed") else "")
            elif check and check["classification"] == "missed_assessment":
                status, reason = "applicable", check["reason"]
            elif rule["in_scope"]:
                status, reason = "applicable", rule["reason"]
            else:
                status, reason = "not_applicable", check["reason"] if check else rule["reason"]
            scope[item] = {"status": status, "reason": reason}
            if check: scope[item]["audit"] = check
        core.freeze("plans/" + cid + ".json", {"case_id": cid, "scope": scope,
                    "candidate_requirements": requirements, "d5c_mode": mode,
                    "clinical_status": "awaiting confirmation", "requirements_status": "awaiting confirmation"})
    return index


def packet_for(entry):
    packet = core.read(ROOT / entry["researcher_case_file"])
    return packet if isinstance(packet, dict) else next(c for c in packet if c["id"] == entry["case_id"])


def validate_rows(rows, expected):
    assert isinstance(rows, list) and len(rows) == len(expected), "Wrong item count"
    assert {r["item"] for r in rows} == set(expected), "Wrong item IDs"
    for row in rows:
        assert row["status"] in {"scored", "indeterminate"}, "Unexpected status for applicable item"
        assert isinstance(row.get("reason"), str) and row["reason"].strip(), "Missing reason"
        assert not non_assessment_reason(row["reason"]), "Non-assessment placeholder instead of a reason"
        assert isinstance(row.get("evidence_quote"), str), "Missing quote field"
        if row["status"] == "scored":
            assert type(row.get("score")) is int and row["score"] in CRITERIA[row["item"]]["allowed_scores"], "Illegal category"
        else:
            assert row.get("score") is None, "Indeterminate needs a null score"


def non_assessment_reason(text):
    return bool(re.fullmatch(r'(?:placeholder|todo|tbd|your (?:reason|explanation) here|n/?a)\.?', text.strip(), re.I))


def requests_for(entry, state, plan):
    cid = entry["case_id"]
    c = packet_for(entry)
    applicable = [i for i in prepare_inputs.ITEMS if plan["scope"][i]["status"] == "applicable"]
    main = [i for i in applicable if i != "D5c"]
    if entry["cohort"] != "complex57":
        visible = OLD.visible_record(c, state)
        output = [("main", OLD.MAIN_SYSTEM, {"visible_record": visible, "applicable_rubric_items": [CRITERIA[i] for i in main]},
                   {"temperature": .7, "top_p": .8}, main, 12288)]
        if "D5c" in applicable:
            body = {"visible_record": visible, "rubric_item": CRITERIA["D5c"], "task_mode": plan["d5c_mode"],
                    "candidate_requirements": plan["candidate_requirements"], "requirements_status": "awaiting confirmation",
                    "source_inventory_not_automatically_received": c.get("facts", []) if plan["d5c_mode"] == "active_acquisition" else [],
                    "availability_rule": "Only an existing allowed record can be returned; absent data are not a negative result or proof that a test was never performed."}
            output.append(("d5c", OLD.D5C_SYSTEM, body, {"temperature": .7, "top_p": .8}, ["D5c"], 8192))
    else:
        output = []
        # Reuse the exact saved judge systems and patient/scoring context.
        for phase, expected in [("main", main), ("d5c", ["D5c"] if "D5c" in applicable else [])]:
            if not expected: continue
            oldpath = RUNS / "complex_bmj_all_models_20261112/requests/grading" / (cid + "__kcl-apex__" + phase + ".json")
            source = core.read(oldpath)
            body = json.loads(source["messages"][1]["content"])
            body["TARGET_RECORD"]["final_answer_unchanged"] = state["final_answer"]
            body["FULL_CRITERIA"] = [CRITERIA[i] for i in expected]
            if phase == "main":
                body["TASK_SCOPE"] = {i: {"in_scope": True, "reason": plan["scope"][i]["reason"]} for i in expected}
                actual_task = body["TARGET_RECORD"]["original_task"]
                body["VERIFIED_WORD_COUNT"] = {**OLD.word_count(state["final_answer"], actual_task), "minimum": 350, "maximum": 500,
                                               "within_range": 350 <= OLD.word_count(state["final_answer"], actual_task)["words"] <= 500,
                                               "extra_tolerance": 0}
            output.append((phase, source["messages"][0]["content"], body,
                           {"temperature": source["temperature"], "top_p": source["top_p"]}, expected, source["max_tokens"]))
    for phase, system, body, parameters, expected, tokens in output:
        assert not any(k in body for k in ("answer_model", "previous_scores", "hidden", "source", "cohort"))
        if phase == "main":
            assert "candidate_requirements" not in body and "CANDIDATE_INFORMATION_REQUIREMENTS" not in body
        if entry["cohort"] == "complex57":
            source = core.read(RUNS / "complex_bmj_all_models_20261112/requests/grading" / (cid + "__kcl-apex__" + phase + ".json"))
            fmt = deepcopy(source["response_format"])
            schema = fmt["json_schema"]["schema"]
            fields = schema["properties"]["items"]["properties"]
            schema["properties"]["items"]["properties"] = {i: fields[i] for i in expected}
            schema["properties"]["items"]["required"] = expected
            for i in expected:
                row = schema["properties"]["items"]["properties"][i]
                row["properties"]["status"] = {"type": "string", "enum": ["scored", "indeterminate"]}
                row["properties"]["score"] = {"anyOf": [{"type": "integer", "enum": CRITERIA[i]["allowed_scores"]}, {"type": "null"}]}
        else:
            row = {"type": "object", "properties": {
                "item": {"type": "string", "enum": expected},
                "status": {"type": "string", "enum": ["scored", "indeterminate"]},
                "score": {"anyOf": [{"type": "integer", "enum": [1, 2, 3, 4, 5]}, {"type": "null"}]},
                "evidence_quote": {"type": "string"}, "reason": {"type": "string"}},
                "required": ["item", "status", "score", "evidence_quote", "reason"], "additionalProperties": False}
            if phase == "main":
                linked = {"type": "object", "properties": {"id": {"type": "string"}, "primary_item": {"type": "string"},
                          "other_items": {"type": "array", "items": {"type": "string"}}, "observation": {"type": "string"}},
                          "required": ["id", "primary_item", "other_items", "observation"], "additionalProperties": False}
                schema = {"type": "object", "properties": {"items": {"type": "array", "items": row, "minItems": len(expected), "maxItems": len(expected)},
                          "linked_observations": {"type": "array", "items": linked}}, "required": ["items", "linked_observations"], "additionalProperties": False}
            else:
                checks = {"type": "object", "properties": {"id": {"type": "string"}, "request_quote": {"type": "string"},
                          "status": {"type": "string", "enum": ["requested_satisfied", "requested_unavailable", "requested_not_returned", "already_supplied", "not_requested", "equivalence_uncertain"]},
                          "reason": {"type": "string"}}, "required": ["id", "request_quote", "status", "reason"], "additionalProperties": False}
                schema = row
                schema["properties"]["requirement_checks"] = {"type": "array", "items": checks}
                schema["required"].append("requirement_checks")
            fmt = {"type": "json_schema", "json_schema": {"name": "full_rubric_" + phase, "strict": True, "schema": schema}}
        parameters["response_format"] = fmt
        core.freeze("requests/grading/" + cid + "__" + phase + ".typed_v2.json", {
            "model": "arc:apex", "messages": [{"role": "system", "content": system}, {"role": "user", "content": json.dumps(body, ensure_ascii=False)}],
            **parameters, "reasoning_effort": "low", "max_tokens": tokens})
    return output


def grade(entry):
    lockdir = ROOT / "grading_locks"
    lockdir.mkdir(exist_ok=True)
    with (lockdir / (entry["case_id"] + ".lock")).open("a+") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        try:
            return _grade_locked(entry)
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def _grade_locked(entry):
    cid = entry["case_id"]
    result_file = ROOT / "grades" / (cid + ".json")
    if result_file.exists(): return True
    ap = ROOT / "answers" / (cid + ".json")
    if not ap.exists(): return False
    state, plan = core.read(ap), core.read(ROOT / "plans" / (cid + ".json"))
    parts = {}
    try:
        for phase, system, body, parameters, expected, tokens in requests_for(entry, state, plan):
            def check(text, expected=expected, phase=phase):
                value = core.parse_json(text)
                if phase == "d5c" and "item" in value:
                    rows = [value]
                elif isinstance(value.get("items"), dict):
                    rows = [{"item": k, **v} for k, v in value["items"].items()]
                else:
                    rows = value.get("items")
                    if isinstance(rows, list):
                        rows = [{**r, "item": r.get("item", r.get("id"))} for r in rows]
                validate_rows(rows, expected)
                return {"raw_parsed": value, "rows": rows}
            request = core.read(ROOT / "requests/grading" / (cid + "__" + phase + ".typed_v2.json"))
            parts[phase] = core.request(cid + ".grade." + phase + ".typed_v2", request["messages"], service="kcl", model="arc:apex",
                                        validator=check, max_tokens=tokens, parameters=parameters)
        rows = {r["item"]: r for part in parts.values() for r in part["rows"]}
        combined = []
        for item in prepare_inputs.ITEMS:
            if item in rows:
                row = deepcopy(rows[item])
                row["status"] = "complete" if row["status"] == "scored" else row["status"]
                quote = row.get("evidence_quote", "")
                row["quote_provenance"] = "exact_answer_match" if quote and quote in state["final_answer"] else "no_excerpt" if not quote else "not_literal_in_answer"
            else:
                row = {"item": item, "status": plan["scope"][item]["status"], "score": None,
                       "reason": plan["scope"][item]["reason"], "evidence_quote": "", "quote_provenance": "no_excerpt"}
                assert row["status"] in {"not_applicable", "applicability_pending"}
            row["applicability_reason"] = plan["scope"][item]["reason"]
            row["review_flags"] = []
            if row["quote_provenance"] == "not_literal_in_answer":
                row["review_flags"].append({"type": "quote_not_literal", "detail": "The saved judge excerpt is not an exact passage from the final answer. Check the input or transcript as well; the original judgement is retained."})
            if plan["scope"][item].get("audit"):
                row["na_audit"] = {k: v for k, v in plan["scope"][item]["audit"].items() if k not in {"automated_suggestion"}}
            combined.append(row)
        d5 = parts.get("d5c", {}).get("raw_parsed", {})
        if d5.get("requirement_checks"):
            next(r for r in combined if r["item"] == "D5c")["requirement_checks"] = d5["requirement_checks"]
        if d5.get("requirements"):
            next(r for r in combined if r["item"] == "D5c")["requirement_checks"] = [
                {"id": k, "status": v["status"], "request_quote": v.get("evidence_quote", ""), "reason": v["reason"]} for k, v in d5["requirements"].items()]
        core.freeze("grades/" + cid + ".json", {"case_id": cid, "configuration": core.MODEL, "judge": "arc:apex / GLM-5.3",
                    "rule_version": core.read(ROOT / "sources/FULL_RUBRIC.json")["version"],
                    "answer_sha256": core.digest(state["final_answer"]), "scores": combined, "parts": parts,
                    "completed_at": core.now(), "clinical_status": "awaiting confirmation", "requirements_status": "awaiting confirmation"})
        print("ASSESSMENT_COMPLETE", cid, "numerical", sum(r["status"] == "complete" for r in combined), "/22 positions", flush=True)
        return True
    except Exception as exc:
        core.save(ROOT / "grading_failures" / (cid + ".json"), {"case_id": cid, "failed_at": core.now(), "error": str(exc)})
        print("GRADE_DEFERRED", cid, core.clean(str(exc))[:160], flush=True)
        return False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cases", nargs="+")
    parser.add_argument("--group", choices=["complex57", "bmj22", "earlier33", "supplied13", "series10"])
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--workers", type=int, default=3)
    args = parser.parse_args()
    manifest = prepare_plans()
    entries = [e for e in manifest["cases"] if (not args.cases or e["case_id"] in args.cases)
               and (not args.group or e["cohort"] == args.group)]
    visited = set()
    while True:
        todo = [e for e in entries if (ROOT / "answers" / (e["case_id"] + ".json")).exists()
                and not (ROOT / "grades" / (e["case_id"] + ".json")).exists() and e["case_id"] not in visited]
        if todo:
            with ThreadPoolExecutor(max_workers=args.workers) as pool:
                futures = {pool.submit(grade, e): e["case_id"] for e in todo}
                for future in as_completed(futures):
                    future.result(); visited.add(futures[future]); run_generate.status()
        status = run_generate.status()
        if not args.watch or status["assessments_complete"] == 135 or (ROOT / "GENERATION_FINISHED.json").exists():
            break
        time.sleep(5)
    print("GRADING_FINISHED", status["assessments_complete"], "/135", flush=True)


if __name__ == "__main__":
    main()
