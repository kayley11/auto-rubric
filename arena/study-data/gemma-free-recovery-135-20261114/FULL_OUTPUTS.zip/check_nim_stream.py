"""One bounded streaming retry, separate from earlier failures."""
import asyncio
from datetime import datetime, timezone
import json
import time

import httpx

from check_routes import CONFIG, ROOT, clean


async def main():
    request = {
        "model": "google/gemma-4-31b-it",
        "messages": [{"role": "user", "content": "Reply with exactly OK."}],
        "temperature": 0, "top_p": 1, "max_tokens": 256, "stream": True,
        "chat_template_kwargs": {"enable_thinking": False},
    }
    result = {"checked_at": datetime.now(timezone.utc).isoformat(), "request": request,
              "paid_fallback": False, "ready_for_cases": False, "events": []}
    started = time.monotonic()
    try:
        async with asyncio.timeout(90):
            async with httpx.AsyncClient(timeout=httpx.Timeout(85, connect=10), trust_env=False) as client:
                async with client.stream("POST", "https://integrate.api.nvidia.com/v1/chat/completions",
                    json=request, headers={"Authorization": "Bearer " + CONFIG["NVIDIA_API_KEY"],
                                           "Accept": "text/event-stream"}) as response:
                    result["http_status"] = response.status_code
                    print("NIM streaming HTTP", response.status_code, flush=True)
                    async for line in response.aiter_lines():
                        if line:
                            result["events"].append(line)
                    text = ""
                    for line in result["events"]:
                        if line.startswith("data:") and line[5:].strip() != "[DONE]":
                            try:
                                part = json.loads(line[5:])
                                text += part.get("choices", [{}])[0].get("delta", {}).get("content") or ""
                            except (ValueError, IndexError):
                                pass
                    result["visible_output"] = text.strip()
                    result["ready_for_cases"] = response.status_code == 200 and text.strip() == "OK"
    except Exception as exc:
        result.update(error_type=type(exc).__name__, error=str(exc))
    result["seconds"] = round(time.monotonic() - started, 3)
    destination = ROOT / ("NIM_STREAM_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + ".json")
    destination.write_text(json.dumps(clean(result), indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("ready_for_cases", "http_status", "error_type", "seconds") if k in result}))


if __name__ == "__main__":
    asyncio.run(main())
