"""Replace non-assessments only; retain all original files and valid item grades."""
from copy import deepcopy
import hashlib

import prepare_inputs
import recovery_core as core
import run_grade


def parse(text, expected, phase):
    value = core.parse_json(text)
    if phase == 'd5c' and 'item' in value:
        rows = [value]
    elif isinstance(value.get('items'), dict):
        rows = [{'item': k, **v} for k, v in value['items'].items()]
    else:
        rows = value.get('items')
        if isinstance(rows, list): rows = [{**r, 'item': r.get('item', r.get('id'))} for r in rows]
    run_grade.validate_rows(rows, expected)
    return {'raw_parsed': value, 'rows': rows}


def repair(entry):
    cid = entry['case_id']
    original_path = core.ROOT / 'grades' / (cid + '.json')
    original = core.read(original_path)
    if not original or (core.ROOT / 'grades_repaired' / (cid + '.json')).exists(): return
    bad = {s['item'] for s in original['scores'] if run_grade.non_assessment_reason(s['reason'])}
    if not bad: return
    answer = core.read(core.ROOT / 'answers' / (cid + '.json'))
    assert original['answer_sha256'] == core.digest(answer['final_answer'])
    result = deepcopy(original)
    repairs = []
    for phase, part in original['parts'].items():
        items = bad & {r['item'] for r in part['rows']}
        if not items: continue
        expected = [r['item'] for r in part['rows']]
        request = core.read(core.ROOT / 'requests/grading' / (cid + '__' + phase + '.typed_v2.json'))
        old_call = core.read(core.ROOT / 'calls/kcl' / (cid + '.grade.' + phase + '.typed_v2') / 'COMPLETE.json')
        assert core.digest(request) == old_call['source_request_sha256'], 'Do not alter a grading request'
        parameters = {k: v for k, v in request.items() if k not in {'model', 'messages', 'max_tokens'}}
        operation = cid + '.grade.' + phase + '.non_placeholder_v3'
        replacement = core.request(operation, request['messages'], service='kcl', model=request['model'],
                                   max_tokens=request['max_tokens'], parameters=parameters,
                                   validator=lambda text, expected=expected, phase=phase: parse(text, expected, phase))
        new_call = core.read(core.ROOT / 'calls/kcl' / operation / 'COMPLETE.json')
        assert new_call['source_request_sha256'] == old_call['source_request_sha256']
        result['parts'][phase + '_technical_repair'] = replacement
        by_item = {row['item']: row for row in replacement['rows']}
        for number, old_row in enumerate(result['scores']):
            if old_row['item'] not in items: continue
            row = {**deepcopy(old_row), **deepcopy(by_item[old_row['item']])}
            row['status'] = 'complete' if row['status'] == 'scored' else row['status']
            quote = row.get('evidence_quote', '')
            row['quote_provenance'] = 'exact_answer_match' if quote and quote in answer['final_answer'] else 'no_excerpt' if not quote else 'not_literal_in_answer'
            row['review_flags'] = []
            if row['quote_provenance'] == 'not_literal_in_answer':
                row['review_flags'].append({'type': 'quote_not_literal', 'detail': 'The saved judge excerpt is not an exact passage from the final answer. Check the input or transcript as well; the original judgement is retained.'})
            if phase == 'd5c':
                raw = replacement['raw_parsed']
                if raw.get('requirement_checks'): row['requirement_checks'] = raw['requirement_checks']
                elif raw.get('requirements'):
                    row['requirement_checks'] = [{'id': k, 'status': v['status'], 'request_quote': v.get('evidence_quote', ''), 'reason': v['reason']} for k, v in raw['requirements'].items()]
            row['technical_repair_phase'] = phase + '_technical_repair'
            result['scores'][number] = row
        repairs.append({'phase': phase, 'items': sorted(items), 'reason': 'Original output contained a non-assessment placeholder instead of a reason.',
                        'replacement_operation': operation, 'unchanged_request_sha256': old_call['source_request_sha256']})
    assert repairs
    for old_row, row in zip(original['scores'], result['scores']):
        if old_row['item'] not in bad: assert row == old_row, 'A valid prior item was changed'
    assert not any(run_grade.non_assessment_reason(s['reason']) for s in result['scores'])
    result.update(original_completed_at=original['completed_at'], completed_at=core.now(), technical_repairs=repairs,
                  original_profile_sha256=hashlib.sha256(original_path.read_bytes()).hexdigest())
    core.freeze('grades_repaired/' + cid + '.json', result)
    print('PLACEHOLDER_REPAIR_COMPLETE', cid, len(bad), 'items; all other items unchanged', flush=True)


def main():
    for entry in prepare_inputs.verify()['cases']: repair(entry)


if __name__ == '__main__': main()
