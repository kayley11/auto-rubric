"""Generate missing answers only, preserving the original task presentations."""
import argparse
from collections import deque
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
import fcntl
import importlib.util
import json
from pathlib import Path
import shutil
import sys

import prepare_inputs
import recovery_core as core

ROOT = core.ROOT
RUNS = ROOT.parent
CONTROLLER = None


def load_controller():
    global CONTROLLER
    if CONTROLLER:
        return CONTROLLER
    source = RUNS / "five_model_33_cases_20261029"
    target = ROOT / "interview_controller"
    target.mkdir(exist_ok=True)
    for name in ("cases.json", "protocol.json", "topics.json", "interview_prompts.json"):
        old = ROOT / "sources/original78/earlier33" / name
        dest = target / name
        if not dest.exists(): shutil.copy2(old, dest)
        assert old.read_bytes() == dest.read_bytes()
    sys.path.insert(0, str(source))
    spec = importlib.util.spec_from_file_location("gemma_recovery_original_controller", source / "run.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ROOT = target
    module.base.ROOT = target
    module.clean = core.clean
    module.save = lambda name, value: core.save(target / name, value)

    def operation(oid, model, messages, validator=None, structured=False):
        if model["id"] == "routing":
            # Keep the original source-report matcher and literal-span checks.
            def check(text):
                result = core.parse_json(text)
                seen, unique = set(), []
                for match in result.get("matches", []):
                    if match.get("id") not in seen:
                        unique.append(match); seen.add(match.get("id"))
                if len(unique) != len(result.get("matches", [])):
                    result["matches"] = unique
                    text = json.dumps(result, ensure_ascii=False)
                return validator(text) if validator else text
            return core.request(oid, messages, service="kcl", model="arc:lite", validator=check, max_tokens=8192)
        assert model["id"] == core.MODEL["id"]
        return core.request(oid, messages, validator=validator, max_tokens=8192)

    module.operation = operation
    CONTROLLER = module
    return module


def generate(entry):
    folder = ROOT / 'case_locks'
    folder.mkdir(exist_ok=True)
    with (folder / (entry['case_id'] + '.lock')).open('a+') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        try:
            return generate_locked(entry)
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def generate_locked(entry):
    cid = entry["case_id"]
    output = ROOT / "answers" / (cid + ".json")
    if output.exists(): return core.read(output)
    try:
        if entry["mode"] == "written-record":
            source = core.read(ROOT / entry["generation_messages"])
            text = core.request(cid + ".final", source["messages"], max_tokens=source.get("max_tokens", 8192))
            state = {"case_id": cid, "model": core.MODEL["model"], "mode": entry["mode"], "turns": [],
                     "final_answer": text, "status": "complete", "finished_at": core.now(),
                     "source_messages_sha256": core.digest(source["messages"])}
        else:
            t = CONTROLLER
            assert t is not None
            case = next(c for c in core.read(ROOT / entry["researcher_case_file"]) if c["id"] == cid)
            state = t.generate(case, core.MODEL)
        state = {**state, "configuration": core.MODEL, "provider": "Google Gemini API — free Gemma endpoint",
                 "thinking": "minimal", "clinical_references": "awaiting confirmation", "requirements_status": "awaiting confirmation"}
        core.freeze("answers/" + cid + ".json", state)
        print("ANSWER_COMPLETE", cid, "turns", len(state.get("turns", [])), "characters", len(state["final_answer"]), flush=True)
        return state
    except Exception as exc:
        core.save(ROOT / "failures" / (cid + ".json"), {"case_id": cid, "failed_at": core.now(), "error": str(exc), "status": "no_complete_answer"})
        print("CASE_DEFERRED", cid, type(exc).__name__, core.clean(str(exc))[:160], flush=True)
        return None


def status():
    manifest = prepare_inputs.verify()
    rows = [{"case_id": c["case_id"], "mode": c["mode"],
             "answer_status": "complete" if (ROOT / "answers" / (c["case_id"] + ".json")).exists() else "no_complete_answer",
             "assessment_status": "complete" if (ROOT / "grades" / (c["case_id"] + ".json")).exists() else "not_yet_assessed"}
            for c in manifest["cases"]]
    result = {"updated_at": core.now(), "case_count": 135, "answers_complete": sum(r["answer_status"] == "complete" for r in rows),
              "assessments_complete": sum(r["assessment_status"] == "complete" for r in rows), "rows": rows,
              "clinical_references": "awaiting confirmation", "requirements_status": "awaiting confirmation"}
    core.save("STATUS.json", result)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cases", nargs="+")
    parser.add_argument("--group", choices=["complex57", "bmj22", "earlier33", "supplied13", "series10"])
    parser.add_argument("--google-compat", action="store_true", help="Same Google model and thinking configuration through Google's compatible endpoint")
    parser.add_argument("--passes", type=int, default=1, help="Bounded resumptions of transport/format failures, never completed answers")
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    core.GOOGLE_COMPAT = args.google_compat
    manifest = prepare_inputs.verify()
    if not any(core.read(p).get("ready_for_cases") for p in ROOT.glob("GOOGLE_SMOKE_*.json")):
        raise RuntimeError("A successful exact-model Google smoke test is required first.")
    rows = [r for r in manifest["cases"] if (not args.cases or r["case_id"] in args.cases)
            and (not args.group or r["cohort"] == args.group)]
    priority = {"C01": -3, "CAND01": -2, "BN01": -1}
    rows.sort(key=lambda r: priority.get(r["case_id"], 0))
    assert not args.cases or set(args.cases) == {r["case_id"] for r in rows}, "Unknown case requested"
    if any(c["mode"] != "written-record" for c in rows): load_controller()
    todo = [row for row in rows if not (ROOT / 'answers' / (row['case_id'] + '.json')).exists()]
    # Materialise already collected final calls first; this makes no model call.
    todo.sort(key=lambda row: not (ROOT / 'calls/google' / (row['case_id'] + '.final') / 'COMPLETE.json').exists())
    pending = deque((row, 1) for row in todo)
    print('GENERATION_QUEUE', len(todo), 'remaining_tasks', 'max_resumptions_per_case', args.passes, flush=True)
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {}
        while pending or futures:
            while pending and len(futures) < args.workers:
                row, attempt = pending.popleft()
                futures[pool.submit(generate, row)] = (row, attempt)
            if not futures: break
            completed, _ = wait(futures, return_when=FIRST_COMPLETED)
            for future in completed:
                row, attempt = futures.pop(future)
                value = future.result()
                if value is None and attempt < args.passes:
                    pending.append((row, attempt + 1))
                    print('CASE_REQUEUED_AT_TAIL', row['case_id'], 'next_resumption', attempt + 1, flush=True)
                result = status()
                print("PROGRESS", result["answers_complete"], "/135 complete answers", flush=True)
    result = status()
    print("GENERATION_FINISHED", result["answers_complete"], "/135", flush=True)
    if not args.cases and not args.group:
        core.save('GENERATION_FINISHED.json', {'finished_at': core.now(), 'answers_complete': result['answers_complete'],
                  'case_count': 135, 'passes': args.passes, 'provider_tpm': 16000, 'target_tpm': 14000,
                  'scheduling': 'per-case retry at queue tail', 'google_transport': 'compatible' if args.google_compat else 'native',
                  'status': 'complete' if result['answers_complete'] == 135 else 'partial'})


if __name__ == "__main__":
    main()
