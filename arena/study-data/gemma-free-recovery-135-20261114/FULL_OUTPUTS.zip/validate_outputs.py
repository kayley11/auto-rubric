"""Check recovery provenance, score categories, preservation and public exports."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

import build_outputs
import prepare_inputs
import recovery_core as core
import run_grade

ROOT = core.ROOT


def main():
    manifest = prepare_inputs.verify()
    criteria = {c['id']: c for c in core.read(ROOT/'sources/FULL_RUBRIC.json')['criteria']}
    counts = Counter(); flags = []; missing = []
    snapshot={r['case_id']:r for r in core.read(ROOT/'RESULT_SUMMARY.json')['cases']}
    for entry in manifest['cases']:
        cid = entry['case_id']; a = core.read(ROOT/'answers'/(cid+'.json')); g = core.effective_grade(cid)
        if not a:
            missing.append(cid); assert not g, 'Cannot grade a missing answer'; continue
        counts['complete_answers'] += 1
        assert a['status']=='complete' and a['final_answer'].strip()
        original = core.read(ROOT/'calls/google'/(cid+'.final')/'COMPLETE.json')
        assert original and original['parsed']==a['final_answer'], 'Saved final text changed'
        raw = core.read(ROOT/original['call_file'])
        assert raw['http_status']==200
        if 'candidates' in raw['response']:
            assert raw['response']['candidates'][0]['finishReason']=='STOP'
            assert 'gemma-4-31b-it' in raw['response'].get('modelVersion','').lower(), 'Wrong/unidentified returned model'
        else:
            assert raw['response']['choices'][0]['finish_reason']=='stop'
            assert 'gemma-4-31b-it' in raw['response'].get('model','').lower(), 'Wrong/unidentified returned model'
        if entry['mode']=='written-record':
            messages=core.read(ROOT/entry['generation_messages'])['messages']
            from google_gemma import make_request
            expected=make_request(messages)
            native_request=raw.get('source_native_request',raw['request'])
            assert expected['contents']==native_request['contents']
            assert expected.get('systemInstruction')==native_request.get('systemInstruction')
            if raw.get('source_native_request'):
                assert messages==raw['request']['messages']
            assert a.get('turns',[])==[]
        else:
            assert len(a['turns'])<=6
            c=run_grade.packet_for(entry)
            source=c['prepared_case']['facts'] if entry['mode']=='prepared-interview' else c['facts']
            allowed={f['id']:f for f in source}
            for t in a['turns']:
                assert 1<=t['number']<=6 and t['question'].strip()
                question=core.read(ROOT/'calls/google'/f'{cid}.question.{t["number"]}'/'COMPLETE.json')
                assert question and question['parsed']['question']==t['question'], 'Recorded question differs from selected model response'
                assert set(f['id'] for f in t['returned'])<=set(allowed), 'Returned an unknown fact ID'
                assert all(f==allowed[f['id']] for f in t['returned']), 'Returned fact wording or time context changed'
                assert len({f.get('release_group',f['id']) for f in t['returned']})<=2
            counts['complete_interviews']+=1
            counts['question_turns']+=len(a['turns'])
        if not g: continue
        counts['complete_profiles']+=1
        assert g['answer_sha256']==core.digest(a['final_answer'])
        if g.get('technical_repairs'):
            old_path=ROOT/'grades'/(cid+'.json'); old_grade=core.read(old_path)
            assert g['original_profile_sha256']==hashlib.sha256(old_path.read_bytes()).hexdigest()
            replaced={item for repair in g['technical_repairs'] for item in repair['items']}
            for before, after in zip(old_grade['scores'],g['scores']):
                if before['item'] not in replaced: assert before==after, 'A valid item changed during a placeholder repair'
            for repair in g['technical_repairs']:
                saved=core.read(ROOT/'calls/kcl'/repair['replacement_operation']/'COMPLETE.json')
                assert saved['source_request_sha256']==repair['unchanged_request_sha256']
        assert len(g['scores'])==22 and {s['item'] for s in g['scores']}==set(criteria)
        plan=core.read(ROOT/'plans'/(cid+'.json'))
        for s in g['scores']:
            counts[s['status']]+=1
            assert s.get('reason','').strip()
            assert not run_grade.non_assessment_reason(s['reason']), 'Selected grade contains a placeholder instead of an assessment'
            if s['status']=='complete':
                assert type(s['score']) is int and s['score'] in criteria[s['item']]['allowed_scores']
                assert plan['scope'][s['item']]['status']=='applicable'
            else:
                assert s['status'] in {'not_applicable','applicability_pending','indeterminate'} and s.get('score') is None
            q=s.get('evidence_quote','')
            if q and q not in a['final_answer']:
                flags.append({'case_id':cid,'item':s['item'],'type':'excerpt_not_exact_final_answer_match','excerpt':q,
                              'note':'May cite the input/transcript, use shortened wording or paraphrase. This is not automatically a clinical error.'})
        essential={r['id'] for r in plan['candidate_requirements'] if r.get('level')=='essential'}
        d5=next(s for s in g['scores'] if s['item']=='D5c')
        checks=d5.get('requirement_checks',[])
        if d5.get('score') is not None and d5['score']>2 and any(r.get('id') in essential and r.get('status') in {'not_requested','not_addressed','partial'} for r in checks):
            flags.append({'case_id':cid,'item':'D5c','type':'possible_essential_requirement_cap_inconsistency',
                          'note':'The returned requirement classifications may conflict with the cap. Preserve the score; check equivalent alternatives and the judge reason.'})
    for entry in manifest['cases']:
        cid=entry['case_id'];folder='complex-cases' if entry['cohort']=='complex57' else 'full-rubric-review'
        before=core.read(ROOT/'website_before'/folder/(cid+'.json'))
        after=core.read(ROOT/'website_update'/folder/(cid+'.json'))
        assert [m for m in before['models'] if 'gemma' not in m['id']]==[m for m in after['models'] if 'gemma' not in m['id']], 'Existing model output changed'
        for field in ['task','initial_facts','reference','requirements','criteria','title','source_url','source_location']:
            assert before.get(field)==after.get(field), 'Existing case/scoring material changed: '+field
        m=next(m for m in after['models'] if m['id']=='gemma4-google')
        assert m['answer_status']==snapshot[cid]['answer_status']
        assert m['service']=='google-free' and m['model_id']=='gemma-4-31b-it'
        assert len(m['scores'])==22
    preserved=core.read(ROOT/'GRADING_WORKER_RESTART_20261114.json',{}).get('completed_grade_sha256',{})
    for filename,h in preserved.items():
        assert hashlib.sha256((ROOT/'grades'/filename).read_bytes()).hexdigest()==h, 'Completed grade overwritten since queue consolidation'
    preserved_answers=core.read(ROOT/'GENERATION_RATE_RESTART_20261114.json',{}).get('completed_answer_sha256',{})
    for filename,h in preserved_answers.items():
        assert hashlib.sha256((ROOT/'answers'/filename).read_bytes()).hexdigest()==h, 'Completed answer overwritten since rate-limit restart'
    checkpoint=core.read(ROOT/'PER_CASE_QUEUE_CHECKPOINT_20261114.json',{})
    for folder, key in [('answers','answer_sha256'),('grades','grade_sha256')]:
        for filename,h in checkpoint.get(key,{}).items():
            assert hashlib.sha256((ROOT/folder/filename).read_bytes()).hexdigest()==h, 'Completed result changed after queue checkpoint'
    from google_gemma import make_request
    for p in (ROOT/'calls/google').glob('*/COMPLETE.json'):
        selected=core.read(p); raw=core.read(ROOT/selected['call_file'])
        if raw.get('source_native_request'):
            assert raw['source_native_request']==make_request(raw['request']['messages'],raw['request']['max_tokens']), 'Compatible transport changed the native input or generation settings'
            assert core.digest(raw['source_native_request'])==selected['source_request_sha256']
    for p in ROOT.rglob('*'):
        if not p.is_file() or '__pycache__' in p.parts or p.suffix in {'.zip','.gz','.lock'}: continue
        text=p.read_text(errors='replace')
        assert not any(secret in text for secret in core.SECRETS), 'Credential in output: '+str(p.relative_to(ROOT))
        assert not re.search(r'(?:nvapi-[A-Za-z0-9_-]{20,}|sk-or-v1-[a-f0-9]{32,}|gsk_[A-Za-z0-9]{20,}|AIza[A-Za-z0-9_-]{20,}|AQ\.[A-Za-z0-9_-]{30,}|hf_[A-Za-z0-9]{20,})',text), 'Credential-shaped value in output: '+str(p.relative_to(ROOT))
    for p in (ROOT/'website_update').rglob('*.json'):
        text=p.read_text()
        assert not re.search(r'/Users/|/private/var/|nvapi-|sk-or-v1-|gsk_',text), 'Private path/credential pattern in public data'
    result={'validated_at':core.now(),'counts':dict(counts),'missing_complete_answers':missing,
            'all_original_input_hashes_verified':True,'all_other_model_outputs_and_numerical_grades_unchanged':True,
            'all_22_item_positions_retained':True,'legal_score_categories_only':True,'no_credentials_detected':True,
            'interview_questions_match_selected_calls_and_returned_facts_match_frozen_source':True,
            'compatible_transport_preserves_original_request_and_generation_settings':True,
            'website_original_case_material_unchanged':True,'completed_grades_preserved_since_queue_consolidation':True,
            'completed_answers_preserved_since_rate_limit_restart':True,
            'per_case_queue_checkpoint_used':bool(checkpoint),
            'completed_answers_and_grades_preserved_since_per_case_queue_checkpoint':True if checkpoint else None,
            'review_flags':flags,'clinical_references':'awaiting confirmation','candidate_requirements':'awaiting confirmation'}
    core.save('VALIDATION.json',result)
    core.save('REVIEW_FLAGS.json',flags)
    print(json.dumps({k:v for k,v in result.items() if k not in ['review_flags','missing_complete_answers']},indent=2))
    print('Review flags:',len(flags),'; missing complete answers:',len(missing))


if __name__=='__main__': main()
