"""Resumable, zero-price five-model comparison of the frozen 33-case cohort."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import sys
import time
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PILOT = ROOT.parents[1]
ARENA = PILOT.parent / "auto rubric/arena"
sys.path.insert(0, str(ARENA))
sys.path.insert(0, str(ROOT))
import engine
import httpx
import patient_matching
import routing_base

spec = importlib.util.spec_from_file_location("saved_autorubric_transport", ROOT.parent / "new_cases_overleaf_20261028/run.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.ROOT = ROOT
KCL = engine.Settings.load()
KCL.timeout = 180
base.SETTINGS, base.PROVIDER = KCL, engine.Provider(KCL)
BLOCKED = {}
FREE_FAILURES = {}


class Deferred(Exception):
    pass


def now():
    return datetime.now(timezone.utc).isoformat()


def read(name):
    return json.loads((ROOT / name).read_text())


def clean(value):
    value = engine.redact(value, KCL.api_key)
    value = engine.redact(value, os.environ.get("OPENROUTER_API_KEY", ""))
    if isinstance(value, str):
        return re.sub(r"hf_[A-Za-z0-9]{20,}", "[REDACTED]", value)
    if isinstance(value, list):
        return [clean(x) for x in value]
    if isinstance(value, dict):
        return {k: "[REDACTED]" if k == "user_id" else clean(v) for k, v in value.items()}
    return value


def save(name, value):
    p = ROOT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(clean(value), ensure_ascii=False, indent=2) + "\n")
    tmp.replace(p)


def verify():
    for path, digest in read("FROZEN.json").items():
        assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest, path


def quota():
    day = datetime.now(timezone.utc).date().isoformat()
    q = read("QUOTA.json") if (ROOT / "QUOTA.json").exists() else {}
    if q.get("day") != day:
        q = {"day": day, "local_attempts": 0, "provider_used": None, "remaining": 0}
    return q


def refresh_quota():
    q = quota()
    key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    if not key.startswith("sk-or-"):
        q.update(remaining=0, reason="OpenRouter key missing or wrong provider prefix")
    else:
        try:
            with httpx.Client(timeout=30) as cli:
                response = cli.get("https://openrouter.ai/api/v1/key", headers={"Authorization": "Bearer " + key})
                response.raise_for_status()
            data = response.json()["data"]
            counter = data.get("free_model_daily_requests", {})
            if not {"used", "remaining", "limit"} <= counter.keys():
                raise ValueError("Daily free-request counter unavailable; refusing unverified free calls.")
            if "baseline_used" not in q:
                probes = [json.loads(p.read_text()) for p in (ROOT / "preflight_calls").glob("*.json")]
                todays_probes = sum(p.get("service") == "openrouter" and p.get("started_at", "").startswith(q["day"]) for p in probes)
                q["baseline_used"] = max(q.get("provider_used") or 0, todays_probes)
            used_for_guard = max(counter["used"], q["baseline_used"] + q["local_attempts"])
            q.update(provider_used=counter["used"], provider_limit=counter["limit"],
                     remaining=max(0, min(50 - used_for_guard, counter["remaining"])),
                     checked_at=now(), reason="")
        except Exception as exc:
            q.update(remaining=0, reason="Cannot verify free quota: " + clean(str(exc)))
    save("QUOTA.json", q)
    return q


def payload_for(model, messages, limit=8192, structured=False):
    body = {"model": model["model"], "messages": messages, "temperature": 0, "max_tokens": limit}
    if model["service"] == "kcl":
        assert model["model"] in {"arc:lite", "arc:chat", "arc:apex"}
        body["reasoning_effort"] = "low"
        if structured:
            body["response_format"] = {"type": "json_object"}
    else:
        assert model["model"] in {"google/gemma-4-31b-it:free", "nvidia/nemotron-3-ultra-550b-a55b:free"}
        body["provider"] = {"max_price": {"prompt": 0, "completion": 0, "request": 0}, "allow_fallbacks": False}
        body["reasoning"] = {"enabled": False} if model["id"] == "gemma4-free" else {"effort": "low", "exclude": True}
        if structured and model["id"] == "gemma4-free":
            body["response_format"] = {"type": "json_object"}
    return body


def operation(oid, model, messages, validator=None, structured=False):
    path = "calls/" + model["id"] + "/" + oid + ".json"
    state = read(path) if (ROOT / path).exists() else {"id": oid, "status": "planned", "attempts": []}
    if state["status"] == "complete":
        return state["parsed"]
    if model["service"] == "openrouter":
        if BLOCKED.get(model["id"], 0) > time.monotonic():
            raise Deferred("Free endpoint deferred after a saved HTTP 429")
        q = quota()
        if q["remaining"] <= 0:
            raise Deferred("Daily free request allowance exhausted or unverified")
    start = sum(a.get("status") != "success" and a.get("http_status") not in {401, 402, 403, 429} for a in state["attempts"])
    # Bounded technical recovery only; a valid answer is never replaced for its score/length.
    for attempt in range(start, 3):
        capture = {"started_at": now(), "service": model["service"]}
        limit = 8192 if attempt == 0 else 16384
        body = payload_for(model, messages, limit, structured)
        settings = KCL if model["service"] == "kcl" else engine.Settings(os.environ.get("OPENROUTER_API_KEY", "").strip(), "https://openrouter.ai/api/v1", timeout=180 if attempt == 0 else 420)
        settings.timeout = 180 if attempt == 0 else 420
        if model["service"] == "openrouter":
            q = quota()
            if q["remaining"] <= 0:
                raise Deferred("Daily free request allowance exhausted")
            q["remaining"] -= 1
            q["local_attempts"] += 1
            save("QUOTA.json", q)
        print(now(), model["id"], oid, "attempt", attempt + 1, flush=True)
        try:
            raw = engine.run_sync(engine.Provider(settings).completion(body, capture))
            if model["service"] == "openrouter" and float(raw.get("usage", {}).get("cost", 0)) != 0:
                BLOCKED[model["id"]] = float("inf")
                capture.update(status="cost_guard_stop", finished_at=now())
                state.update(status="cost_guard_stop")
                state["attempts"].append(capture)
                save(path, state)
                raise Deferred("Nonzero provider cost reported: this service has been stopped")
            choice = raw["choices"][0]
            value = choice["message"].get("content", "").strip()
            if not value or choice.get("finish_reason") == "length":
                raise ValueError("No complete visible output or output-token truncation")
            if validator:
                value = validator(value)
            state.update(status="complete", parsed=value)
            capture["status"] = "success"
        except Deferred:
            raise
        except Exception as exc:
            capture.update(status="error", error=clean(str(exc)))
            state["status"] = "error"
        capture["finished_at"] = now()
        state["attempts"].append(capture)
        save(path, state)
        if state["status"] == "complete":
            return state["parsed"]
        if model["service"] == "openrouter" and capture.get("http_status") in {401, 402, 403, 429}:
            FREE_FAILURES[model["id"]] = FREE_FAILURES.get(model["id"], 0) + 1
            error = str(capture.get("provider_error", ""))
            if "daily" in error.lower() or "free_model_daily" in error:
                q = quota()
                q["remaining"] = 0
                save("QUOTA.json", q)
            BLOCKED[model["id"]] = time.monotonic() + 90 if FREE_FAILURES[model["id"]] == 1 and capture.get("http_status") == 429 else float("inf")
            raise Deferred("Free endpoint returned HTTP " + str(capture["http_status"]) + "; error saved, no paid fallback")
        if attempt < 2:
            time.sleep(3)
    raise RuntimeError("Three saved technical failures: " + model["id"] + "/" + oid)


def parsed(text):
    return json.loads(re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip()))


def validate_question(text):
    value = parsed(text)
    assert value.get("action") in {"ask", "finish"}
    assert isinstance(value.get("assessment"), dict) and isinstance(value["assessment"].get("summary"), str)
    if value["action"] == "ask":
        assert isinstance(value.get("question"), str) and value["question"].strip()
        assert isinstance(value.get("topics"), list) and 1 <= len(value["topics"]) <= 2
        assert set(value["topics"]) <= set(read("topics.json"))
    return value


def render(turns, notes=False):
    output = []
    for t in turns:
        text = f"Q{t['number']} actual request: {t['question']}"
        if notes:
            text += "\nPublic assessment note: " + json.dumps(t["assessment"], ensure_ascii=False)
        for f in t["returned"]:
            text += f"\n[{f['id']}; {f['channel']}; {f.get('context', f.get('period', 'presentation'))}] {f['text']}"
        text += "\nEnvironment feedback: " + t["feedback"]
        output.append(text)
    return "\n\n".join(output)


def route(case, value, state, model):
    if case["mode"] == "prepared-interview":
        c = case["prepared_case"]
        released = set(c["opening_fact_ids"]) | {f["id"] for t in state["turns"] for f in t["returned"]}
        old_turns = [{"question": t["question"], "fixed_records": t.get("returned", []), "released_fact_ids": [f["id"] for f in t["returned"]], "doctor_output": t.get("doctor_output", {})} for t in state["turns"]]
        patients, records, feedback = patient_matching.select_with_context(c, value, released, routing_base.select_facts, old_turns)
        selected = patients + records
        groups = list(dict.fromkeys(f.get("release_group", f["id"]) for f in selected))[:2]
        selected = [f for f in selected if f.get("release_group", f["id"]) in groups]
        if not selected:
            feedback.append("No matching selected statement or report is available for this request at this decision point. This is not a negative result or evidence that testing was never performed. Change to another useful question or finish with this limitation recorded.")
        else:
            feedback.append("Only the displayed statements have been supplied. Any other requested detail remains unknown.")
        return deepcopy(selected), " ".join(feedback), {"method": "Frozen deterministic matching", "status": "technical selections saved"}
    inventory = [{k: f[k] for k in ("id", "channel", "period", "text")} for f in case["facts"]]
    system = (
        "Match an ACTUAL information request to existing fixed source facts. Return JSON only: "
        '{"matches":[{"id":"existing fact ID","request_span":"literal words from actual request"}],"unanswered_spans":["literal request with no supplied answer"]}. '
        "Select only groups directly answering the request; assessment notes are not requests. Do not infer the diagnosis or add facts. "
        "Respect personal versus family history, requested test type, admission, dates and decision point. "
        "A general request for all investigations does not acquire every report. List matches in request order. "
        "No match is valid; unavailable is not normal, negative or not performed."
    )
    question = value["question"]
    content = "Decision point: " + case["decision_point"] + "\nFixed available groups:\n" + json.dumps(inventory, ensure_ascii=False)
    content += "\nPreviously received conversation, for anaphora only:\n" + render(state["turns"]) + "\nACTUAL REQUEST:\n" + question
    allowed = {f["id"] for f in case["facts"]}
    def validate(text):
        result = parsed(text)
        assert isinstance(result.get("matches"), list) and isinstance(result.get("unanswered_spans", []), list)
        assert len({x["id"] for x in result["matches"]}) == len(result["matches"])
        for match in result["matches"]:
            assert match["id"] in allowed and match["request_span"] and match["request_span"].lower() in question.lower()
        return result
    selector = {"id": "routing", "model": "arc:lite", "service": "kcl"}
    decision = operation(case["id"] + "." + model["id"] + ".route." + str(len(state["turns"]) + 1), selector,
                         [{"role": "system", "content": system}, {"role": "user", "content": content}], validate, True)
    ids = [m["id"] for m in decision["matches"][:2]]
    facts = [deepcopy(next(f for f in case["facts"] if f["id"] == fid)) for fid in ids]
    feedback = []
    if len(decision["matches"]) > 2:
        feedback.append("At most two matching source groups are returned per turn; other requested groups are deferred.")
    if decision.get("unanswered_spans"):
        feedback.append("No supplied answer for: " + "; ".join(decision["unanswered_spans"]) + ".")
    if not facts:
        feedback.append("No matching information is supplied at this decision point. This is not a negative clinical finding.")
    feedback.append("Do not infer unreported values, results or the performance of a test.")
    decision.update(method="Fixed semantic matcher; literal spans and existing IDs validated", technical_review="awaiting review")
    return facts, " ".join(feedback), decision


def generate(case, model):
    path = "answers/" + model["id"] + "/" + case["id"] + ".json"
    state = read(path) if (ROOT / path).exists() else {"case_id": case["id"], "model": model["model"], "mode": case["mode"], "turns": [], "status": "started", "started_at": now()}
    if state["status"] == "complete":
        return state
    initial = "Case information supplied:\n" + case["initial_facts"] + "\nFinal task:\n" + case["task"]
    if case["mode"] != "written-record":
        system = read("interview_prompts.json")["DOCTOR_SYSTEM"] + "\nDo not state a model or provider identity.\nStandard topic IDs:\n" + json.dumps(read("topics.json"))
        while len(state["turns"]) < 6 and not state.get("interview_finished"):
            number = len(state["turns"]) + 1
            content = initial + "\n\nActual interview so far:\n" + render(state["turns"], True) + f"\nQuestion opportunity {number} of 6."
            value = operation(case["id"] + ".question." + str(number), model, [{"role": "system", "content": system}, {"role": "user", "content": content}], validate_question, True)
            if value["action"] == "finish":
                state.update(interview_finished=True, closing_note=value["assessment"])
                save(path, state)
                break
            facts, feedback, selection = route(case, value, state, model)
            previous = {f["id"] for t in state["turns"] for f in t["returned"]}
            repeated = [f["id"] for f in facts if f["id"] in previous]
            if repeated:
                feedback += " Previously returned: " + ", ".join(repeated) + ". Repetition does not establish new information."
            state["turns"].append({"number": number, "question": value["question"], "assessment": value["assessment"], "doctor_output": value,
                                    "returned": facts, "feedback": feedback, "selection": selection})
            state["status"] = "interviewing"
            save(path, state)
    user = initial
    if state["turns"]:
        user += "\n\nActual interview and public notes:\n" + render(state["turns"], True)
    user += "\n\nNow give the final answer for the original audience. No further request will receive a reply.\n" + engine.WORD_COUNT_RULE
    answer = operation(case["id"] + ".final", model, [{"role": "system", "content": engine.GEN_SYSTEM + " Do not identify your model or provider."}, {"role": "user", "content": user}])
    state.update(status="complete", final_answer=answer, word_count=engine.word_count_info(answer, case["task"]), interview_finished=True, finished_at=now())
    save(path, state)
    print("ANSWER", case["id"], model["id"], "turns", len(state["turns"]), "words", state["word_count"]["words"], flush=True)
    return state


JUDGE_SYSTEM = base.JUDGE_SYSTEM.replace(
    "Only interactive requests before the final assessment can satisfy the declared deadline; final recommendations are not executed requests.",
    "Respect each frozen requirement deadline. Normally only actual requests before the final assessment count; final recommendations are not executed requests. C05 explicitly allows final patient-directed questions for C05.priorities only.",
)


def grade_input(case, state, op):
    item = op["item"]
    query = "Opening actually supplied:\n" + case["initial_facts"] + "\nDecision point: " + case["decision_point"] + "\nOriginal task:\n" + case["task"]
    query += "\nActual requests and information returned:\n" + render(state["turns"], notes=item == "D5c")
    if item == "D5c":
        query += "\nCandidate requirements, awaiting confirmation:\n" + json.dumps(case["requirements"], ensure_ascii=False)
        query += "\nFixed source inventory (reviewer-only availability, not automatically elicited):\n" + json.dumps([{k: f[k] for k in ("id", "channel", "text")} for f in case["facts"]], ensure_ascii=False)
        query += "\nUnavailable named material: " + case.get("unavailable", "Other named reports are not supplied; missing does not mean not performed.")
        submission = "Executed requests:\n" + "\n".join(f"Q{t['number']}: {t['question']}" for t in state["turns"])
        if case["id"] == "C05":
            submission += "\nFinal patient explanation (only literal closing questions may satisfy C05.priorities):\n" + state["final_answer"]
    else:
        if item != "D3a":
            reference = case["reference"]
            try:
                structured = json.loads(reference)
                if isinstance(structured, dict):
                    reference = json.dumps({k: v for k, v in structured.items() if k not in {"sources", "source_checked_date", "review_status"}}, ensure_ascii=False)
            except (ValueError, TypeError):
                pass
            query += "\nProvisional reference, awaiting confirmation; never require hidden facts:\n" + reference
        submission = state["final_answer"]
    assert not re.search(r"arc:(?:lite|apex|chat)|old_score|prior verdict|https?://", query)
    return query, submission


base.grade_input, base.JUDGE_SYSTEM = grade_input, JUDGE_SYSTEM


def grade(case, model, state):
    for item in case["criteria"]:
        path = "grades/" + model["id"] + "/" + case["id"] + "." + item + ".json"
        rec = read(path) if (ROOT / path).exists() else {"operation": {"case": case["id"], "item": item, "condition": "primary", "repeat": 1}, "answer_model": model["id"], "attempts": [], "status": "planned"}
        if rec["status"] == "complete":
            continue
        for n in range(len(rec["attempts"]), 3):
            capture = {"started_at": now()}
            print(now(), "JUDGE", case["id"], model["id"], item, "attempt", n + 1, flush=True)
            try:
                KCL.timeout = 180 if n == 0 else 420
                result = engine.run_sync(base.one_grade(case, state, rec["operation"], capture))
                rec.update(status="complete", result=result)
                capture["status"] = "success"
            except Exception as exc:
                rec["status"] = "error"
                capture.update(status="error", error=clean(str(exc)))
            capture["finished_at"] = now()
            rec["attempts"].append(capture)
            save(path, rec)
            if rec["status"] == "complete":
                print("GRADE", case["id"], model["id"], item, rec["result"]["label"], flush=True)
                break
            if n < 2:
                time.sleep(3)


def status():
    cases = read("cases.json")
    models = read("protocol.json")["answer_models"]
    out = {"updated_at": now(), "planned_answers": 165, "planned_item_ratings": read("protocol.json")["planned_item_ratings"], "models": {}}
    for model in models:
        rows = [read(str(p.relative_to(ROOT))) for p in sorted((ROOT / "answers" / model["id"]).glob("*.json"))]
        gs = [read(str(p.relative_to(ROOT))) for p in sorted((ROOT / "grades" / model["id"]).glob("*.json"))]
        out["models"][model["id"]] = {"answers_complete": sum(r["status"] == "complete" for r in rows), "partial_interviews": sum(r["status"] != "complete" for r in rows),
            "item_ratings_complete": sum(g["status"] == "complete" for g in gs), "item_rating_failures": sum(g["status"] == "error" for g in gs)}
    out["completed_answers"] = sum(m["answers_complete"] for m in out["models"].values())
    out["completed_ratings"] = sum(m["item_ratings_complete"] for m in out["models"].values())
    out["clinical_status"] = "awaiting confirmation"
    out["free_quota"] = quota()
    save("STATUS.json", out)
    return out


def checks():
    verify()
    protocol = read("protocol.json")
    assert len(read("cases.json")) == 33 and len(read("PLAN.json")) == 165
    for m in protocol["answer_models"]:
        body = payload_for(m, [{"role": "user", "content": "test"}])
        if m["service"] == "openrouter":
            assert body["model"].endswith(":free") and all(v == 0 for v in body["provider"]["max_price"].values())
            assert body["provider"]["allow_fallbacks"] is False and "models" not in body
    try:
        payload_for({"id": "invalid", "model": "paid/model", "service": "openrouter"}, [])
    except AssertionError:
        pass
    else:
        raise AssertionError("Paid model was not rejected")
    assert {c["id"] for c in read("cases.json") if c["mode"] == "written-record"} == {"N01", "N03", "N06"}
    for c in read("cases.json"):
        assert c["criteria"] and ("D5c" not in c["criteria"] or c["requirements"])
        grade_input(c, {"turns": [], "final_answer": "Test answer"}, {"item": c["criteria"][0]})
    c = next(c for c in read("cases.json") if c["id"] == "C01")
    example = {"question": "Can I see the urine protein and kidney function results?", "topics": ["routine_laboratory"], "record_period": "any", "assessment": {"summary": "Check renal evidence", "certainty": "working"}}
    facts, feedback, _ = route(c, example, {"turns": []}, {"id": "offline-check"})
    assert not facts and "not a negative result" in feedback
    print("PASS: cohort, frozen inputs, zero-price allowlist, paid-model rejection and blinded judge windows.")


def main(models=None, limit=None):
    import fcntl
    import report
    lock = (ROOT / ".run.lock").open("w")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    (ROOT / "RUN_PID").write_text(str(os.getpid()) + "\n")
    verify()
    protocol = read("protocol.json")
    selected = [m for m in protocol["answer_models"] if not models or m["id"] in models]
    cases = {c["id"]: c for c in read("cases.json")}
    refresh_quota()
    events = read("EVENTS.json") if (ROOT / "EVENTS.json").exists() else []
    attempted = 0
    for cid in protocol["case_order"]:
        for model in selected:
            if limit is not None and attempted >= limit:
                print(json.dumps(status(), indent=2), flush=True)
                return
            try:
                state = generate(cases[cid], model)
                grade(cases[cid], model, state)
                events.append({"at": now(), "case": cid, "model": model["id"], "status": "processed"})
            except Deferred as exc:
                events.append({"at": now(), "case": cid, "model": model["id"], "status": "deferred", "reason": str(exc)})
                print("DEFERRED", cid, model["id"], str(exc), flush=True)
            except Exception as exc:
                events.append({"at": now(), "case": cid, "model": model["id"], "status": "technical_error", "reason": clean(str(exc))})
                print("TECHNICAL ERROR", cid, model["id"], clean(str(exc)), flush=True)
            save("EVENTS.json", events)
            status()
            report.write()
            attempted += 1
    print(json.dumps(status(), indent=2), flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--check", action="store_true")
    p.add_argument("--models", nargs="+")
    p.add_argument("--limit", type=int)
    args = p.parse_args()
    checks() if args.check else main(args.models, args.limit)
