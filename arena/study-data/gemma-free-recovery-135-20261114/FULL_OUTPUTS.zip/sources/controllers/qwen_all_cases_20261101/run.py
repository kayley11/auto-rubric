"""Collect Qwen separately, reusing existing controllers and AutoRubric graders."""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import csv
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
PILOT = ROOT.parents[1]
REPO = PILOT.parent / "auto rubric"
sys.path.insert(0, str(REPO / "arena"))
import engine
import httpx
from dotenv import dotenv_values
sys.path.insert(0, str(ROOT.parent / "bmj_22_five_model_20261031"))

MODEL = {"id": "qwen38-groq", "model": "qwen/qwen3.8-27b", "service": "groq"}
QWEN_OUTPUT_CAP = 1000
KEY = (os.environ.get("GROQ_API_KEY") or dotenv_values(REPO / ".env").get("GROQ_API_KEY", "")).strip()


class Deferred(RuntimeError):
    def __init__(self, message, wait=0):
        super().__init__(message)
        self.wait = wait


def now():
    return datetime.now(timezone.utc).isoformat()


def read(path, default=None):
    return json.loads(path.read_text()) if path.exists() else default


def clean(value):
    if isinstance(value, dict):
        return {k: "[REDACTED]" if k.lower() in {"authorization", "api_key", "cookie", "user_id"} else clean(v) for k, v in value.items()}
    if isinstance(value, list):
        return [clean(v) for v in value]
    if isinstance(value, str):
        value = engine.redact(value, KEY)
        return re.sub(r"\b(?:gsk_|hf_)[A-Za-z0-9]{16,}", "[REDACTED]", value)
    return value


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(clean(value), ensure_ascii=False, indent=2) + "\n")
    temp.replace(path)


def verify():
    manifest = read(ROOT / "MANIFEST.json")
    for name, expected in manifest["source_hashes"].items():
        assert hashlib.sha256((ROOT.parent / name).read_bytes()).hexdigest() == expected, name
    for name, expected in manifest["frozen_hashes"].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    assert len(manifest["cases"]) == 78
    assert sum(len(c["criteria"]) for c in manifest["cases"]) == 427
    return manifest


def duration(value):
    if not value:
        return 0.0
    try:
        return float(value)
    except ValueError:
        return sum(float(n) * {"ms": .001, "s": 1, "m": 60, "h": 3600, "d": 86400}[u]
                   for n, u in re.findall(r"([\d.]+)(ms|s|m|h|d)", value))


def groq(payload, capture):
    assert payload["model"] == MODEL["model"]
    if not KEY:
        raise Deferred("Groq Key is not configured; no request sent.")
    rate = read(ROOT / "RATE_STATE.json", {})
    delay = rate.get("not_before", 0) - time.time()
    if delay > 0:
        raise Deferred("Waiting for the recorded free-provider limit.", delay)
    started = time.monotonic()
    capture.update(started_at=now(), request=payload, service="groq")
    with httpx.Client(timeout=180, trust_env=False, follow_redirects=False) as client:
        response = client.post("https://api.groq.com/openai/v1/chat/completions", json=payload,
                               headers={"Authorization": "Bearer " + KEY})
    capture.update(http_status=response.status_code, elapsed_seconds=round(time.monotonic()-started, 3))
    headers = {k:v for k,v in response.headers.items() if k.startswith("x-ratelimit-") or k == "retry-after"}
    capture["rate_headers"] = headers
    body = response.json()
    remaining = int(headers.get("x-ratelimit-remaining-tokens", "8000"))
    reset = duration(headers.get("x-ratelimit-reset-tokens", ""))
    # The account also enforces OTPM=1000. Honour actual retry durations instead
    # of waiting for an arbitrary 5000-token reserve after successful requests.
    pause = 0
    save(ROOT / "RATE_STATE.json", {"at": now(), "headers": headers, "not_before":time.time()+pause})
    if int(headers.get("x-ratelimit-limit-requests", "1000")) > 1000 or int(headers.get("x-ratelimit-limit-tokens", "8000")) > 8000:
        raise Deferred("Observed account limits no longer match the verified Free-plan limits; verify the plan before further calls.")
    if response.status_code >= 400:
        capture["provider_error"] = clean(body)
        if response.status_code == 429:
            message = str(body.get("error", {}).get("message", ""))
            if re.search(r"request too large|exceed.{0,30}enforced limit", message, re.I):
                raise Deferred("Request exceeds the Free-plan per-request allowance; waiting cannot repair it. " + message)
            wait = duration(headers.get("retry-after", ""))
            found = re.search(r"try again in ([\d.hms]+)", message, re.I)
            wait = max(wait, duration(found.group(1)) if found else 0)
            if not wait and re.search(r"tokens per day|requests per day|daily|\bTPD\b|\bRPD\b", message, re.I):
                raise Deferred("Daily Free allowance exhausted; no reliable reset time supplied. Saved progress needs a later resume.")
            wait = max(wait, reset, 5) + 1
            save(ROOT / "RATE_STATE.json", {"at":now(), "headers":headers, "not_before":time.time()+wait, "reason":message})
            raise Deferred("Groq free rate limit: " + message, wait)
        raise ValueError(f"Groq returned HTTP {response.status_code}; original error saved.")
    capture["response"] = {k: body[k] for k in ("id", "model", "created", "usage") if k in body}
    capture["response"]["choices"] = [
        {"finish_reason":c.get("finish_reason"), "message":{"role":"assistant", "content":c.get("message",{}).get("content")}}
        for c in body.get("choices", [])]
    return body


def normalise_routing(text):
    """Deduplicate validated fixed-fact IDs, preserving first-match order."""
    value = json.loads(re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip()))
    if not isinstance(value, dict) or not isinstance(value.get("matches"), list):
        return text, []
    seen, matches, removed = set(), [], []
    for match in value["matches"]:
        fid = match.get("id")
        if fid in seen:
            removed.append(fid)
        else:
            seen.add(fid)
            matches.append(match)
    if removed:
        value["matches"] = matches
        return json.dumps(value,ensure_ascii=False), removed
    return text, []


def load_batch(batch):
    names = {"earlier33":"five_model_33_cases_20261029", "bmj22":"bmj_22_five_model_20261031",
             "supplied13":"supplied_13_five_model_20261101", "series10":"case_series_10_five_model_20261101"}
    source = ROOT.parent / names[batch]
    path = source / ("run.py" if batch == "earlier33" else "study.py")
    spec = importlib.util.spec_from_file_location("qwen_source_" + batch, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    target = ROOT / "cohorts" / batch
    t = module if batch == "earlier33" else module.t
    module.ROOT = t.ROOT = t.base.ROOT = target
    if hasattr(module, "saved"):
        module.saved.ROOT = target
    if hasattr(module, "driver"):
        module.driver.ROOT = target
    t.clean = clean

    original_payload = t.payload_for

    def operation(oid, model, messages, validator=None, structured=False):
        path = target / "calls" / model["id"] / (oid + ".json")
        state = read(path, {"id":oid, "status":"planned", "attempts":[]})
        if state["status"] == "complete":
            return state["parsed"]
        if model["id"] == "routing" and validator:
            for index, old in enumerate(state["attempts"]):
                choices = old.get("response",{}).get("choices",[])
                if not choices or choices[0].get("finish_reason") != "stop":
                    continue
                try:
                    text, removed = normalise_routing(choices[0]["message"]["content"])
                    if not removed:
                        continue
                    value = validator(text)
                except (ValueError, TypeError, KeyError, AssertionError):
                    continue
                state.update(status="complete",parsed=value,
                    technical_recovery={"at":now(),"source_attempt":index+1,
                        "method":"Deduplicate fixed-fact IDs in first-match order, then rerun unchanged source-ID and literal-span validation.",
                        "duplicate_ids_removed":removed,"http_request_made":False})
                save(path,state)
                return value
        technical = sum(a.get("status") == "error" and a.get("http_status") != 429 for a in state["attempts"])
        while technical < 3:
            capture = {"started_at":now(), "service":model["service"]}
            if model["service"] == "groq":
                payload = {"model":MODEL["model"], "messages":messages, "temperature":0,
                           "max_tokens":QWEN_OUTPUT_CAP, "reasoning_effort":"none"}
                if structured:
                    payload["response_format"] = {"type":"json_object"}
            else:
                payload = original_payload(model, messages, 8192, structured)
            if model["service"] != "groq" or read(ROOT / "RATE_STATE.json",{}).get("not_before",0) <= time.time():
                print(now(), batch, model["id"], oid, "call", len(state["attempts"])+1, flush=True)
            try:
                raw = groq(payload, capture) if model["service"] == "groq" else engine.run_sync(t.base.PROVIDER.completion(payload, capture))
                choice = raw["choices"][0]
                value = choice["message"].get("content", "")
                if not isinstance(value, str) or not value.strip() or choice.get("finish_reason") == "length":
                    raise ValueError("Empty or technically truncated visible output; retained for technical recovery.")
                if validator and model["id"] == "routing":
                    value,removed=normalise_routing(value)
                    if removed:
                        capture["output_normalisation"]={"duplicate_ids_removed":removed,"first_match_order_preserved":True}
                value = validator(value.strip()) if validator else value.strip()
                capture.update(status="success", finished_at=now())
                state["attempts"].append(capture)
                state.update(status="complete", parsed=value)
                save(path, state)
                return value
            except Deferred as exc:
                if "http_status" in capture:
                    capture.update(status="deferred", finished_at=now(), error=str(exc))
                    state["attempts"].append(capture)
                    state.update(status="deferred")
                    save(path, state)
                raise
            except Exception as exc:
                capture.update(status="error", finished_at=now(), error=clean(str(exc)))
                state["attempts"].append(capture)
                state.update(status="error")
                save(path, state)
                technical += 1
                if capture.get("http_status") in {401,402,403,404,413,429}:
                    raise Deferred("Service/input access failure; preserved without changing the model or shortening evidence.") from exc
                if technical < 3:
                    time.sleep(2)
        raise ValueError("Three saved technical failures: " + oid)

    t.operation = operation
    if batch == "bmj22":
        module.install(t, module.grade_input, target)
    elif batch == "series10":
        module.saved.install(t, module.grade_input, target)
    if batch == "supplied13":
        def grade_input(case, state, op):
            query = ('Evidence actually supplied to the answering model:\n'+case['initial_facts']+
                     '\nTask actually supplied to the answering model:\n'+case['task']+
                     '\nAssess at the point described by those facts and task. No additional events, planned interventions, test results or future outcomes are established by research metadata.'+
                     '\nWritten task; no executed question/response opportunity. Judge only the selected item. D5c is not selected.')
            if op['item'] != 'D3a':
                query += '\nProvisional review points, awaiting confirmation; not a unique answer or a diagnostic gold standard:\n'+case['reference']
            return query, state['final_answer']
        module.saved.install(t, grade_input, target)
    return t, target


def grade_case(t, target, case, state):
    """First valid judgment only; append bounded, disclosed format recovery."""
    for item in case["criteria"]:
        path=target/"grades"/MODEL["id"]/(case["id"]+"."+item+".json")
        record=read(path,{"operation":{"case":case["id"],"item":item,"condition":"primary","repeat":1},
                          "answer_model":MODEL["id"],"attempts":[],"status":"planned"})
        if record["status"]=="complete":
            continue
        for attempt in range(len(record["attempts"]),6):
            capture={"started_at":now()}
            recovery=attempt>=3
            print(now(),"JUDGE",case["id"],item,"attempt",attempt+1,"format recovery" if recovery else "primary",flush=True)
            try:
                t.KCL.timeout=420 if recovery else (180 if attempt==0 else 420)
                if recovery:
                    criterion=t.base.criterion(item)
                    pairs="; ".join(f"position {i}: exact label {json.dumps(o.label)}" for i,o in enumerate(criterion.options,1))
                    clarification=("\nTechnical JSON output clarification; clinical anchors and evidence are unchanged. "
                        "selected_option is a one-based POSITION and selected_label is the exact LABEL at that position: "+pairs+
                        ". Never put the anchor description in selected_label. Include selected_option, selected_label and explanation, "
                        "then close the JSON object immediately; do not append whitespace.")
                    capture["technical_recovery"]={"kind":"output-format clarification","clinical_inputs_unchanged":True,"label_mapping":pairs}
                    with patch.object(t.base,"JUDGE_SYSTEM",t.base.JUDGE_SYSTEM+clarification):
                        result=engine.run_sync(t.base.one_grade(case,state,record["operation"],capture))
                else:
                    result=engine.run_sync(t.base.one_grade(case,state,record["operation"],capture))
                record.update(status="complete",result=result)
                capture["status"]="success"
            except Exception as exc:
                record["status"]="error"
                capture.update(status="error",error=clean(str(exc)))
            capture["finished_at"]=now()
            record["attempts"].append(capture)
            save(path,record)
            if record["status"]=="complete":
                break
            if capture.get("http_status") in {401,402,403,429}:
                raise Deferred("Judge access/rate limit; saved progress retained.")
            if attempt<5:
                time.sleep(2)


def written_answer(t, target, case):
    path = target / "answers" / MODEL["id"] / (case["id"] + ".json")
    state = read(path, {})
    if state.get("status") == "complete":
        return state
    messages = read(target / "written_messages.json")[case["id"]]
    text = t.operation(case["id"]+".final", MODEL, messages)
    state = {"case_id":case["id"], "model":MODEL["model"], "mode":case["mode"], "turns":[],
             "final_answer":text, "word_count":engine.word_count_info(text, case["task"]),
             "status":"complete", "finished_at":now()}
    save(path, state)
    return state


def report():
    manifest = read(ROOT / "MANIFEST.json")
    rows, scores, comparison, resources = [], [], [], Counter()
    raw = ["QWEN3.8-27B — ALL CURRENT CASES", "Clinical references and essential information: awaiting confirmation.",
           "Original visible outputs are preserved; no private reasoning is requested.", ""]
    for entry in manifest["cases"]:
        target = ROOT / "cohorts" / entry["batch"]
        case = next(c for c in read(target / "cases.json") if c["id"] == entry["case"])
        answer = read(target / "answers" / MODEL["id"] / (case["id"]+".json"), {})
        grades = [read(target / "grades" / MODEL["id"] / (case["id"]+"."+cid+".json"), {}) for cid in case["criteria"]]
        completed = sum(g.get("status")=="complete" for g in grades)
        rows.append({**entry, "answer_status":answer.get("status","pending"), "ratings_complete":completed,
                     "rounds":len(answer.get("turns",[])), "words":answer.get("word_count",{}).get("words")})
        raw += ["\n"+"="*70, case["id"]+" — "+case["title"], "Batch: "+entry["batch"],
                "Audience: "+case["audience"], "INPUT\n"+case["initial_facts"], "TASK\n"+case["task"],
                "ACTUAL INTERVIEW\n"+json.dumps(answer.get("turns",[]),ensure_ascii=False,indent=2),
                "ANSWER\n"+answer.get("final_answer","No complete answer saved."),
                "REFERENCE — awaiting confirmation\n"+case["reference"]]
        for cid, grade in zip(case["criteria"],grades):
            result = grade.get("result",{})
            scores.append({"case":case["id"], "batch":entry["batch"], "model":MODEL["model"], "item":cid,
                           "status":grade.get("status","pending"), "score":result.get("label",""), "reason":result.get("reason","")})
            raw += [cid+": "+str(result.get("label","Not scored")), result.get("reason","")]
            source_name=read(target / "source_protocol.json").get("source_batch")
            source_name=source_name or {"earlier33":"five_model_33_cases_20261029", "bmj22":"bmj_22_five_model_20261031", "supplied13":"supplied_13_five_model_20261101", "series10":"case_series_10_five_model_20261101"}[entry["batch"]]
            source=ROOT.parent/source_name
            selection=read(source/"GRADE_SELECTION.json",{})
            source_grades=source/selection.get("relative_directory","grades")
            row={"case":case["id"],"batch":entry["batch"],"item":cid}
            for old in read(target/"source_protocol.json")["answer_models"]:
                old_grade=read(source_grades/old["id"]/(case["id"]+"."+cid+".json"),{})
                row[old["model"]]=old_grade.get("result",{}).get("label","") if old_grade.get("status")=="complete" else ""
            row[MODEL["model"]]=result.get("label","") if grade.get("status")=="complete" else ""
            comparison.append(row)
    for file in sorted((ROOT / "cohorts").glob("*/calls/*/*.json")) + sorted((ROOT / "cohorts").glob("*/grades/*/*.json")):
        record=read(file,{})
        raw += ["\nSAVED RECORD: "+str(file.relative_to(ROOT)),json.dumps(record,ensure_ascii=False,indent=2)]
        for a in record.get("attempts",[]):
            usage=a.get("response",{}).get("usage") or {}
            resources["requests"]+=1
            for k in ["prompt_tokens","completion_tokens","total_tokens"]:
                resources[k]+=usage.get(k,0) or 0
    status={"updated_at":now(), "planned_answers":78, "answers_complete":sum(r["answer_status"]=="complete" for r in rows),
            "planned_ratings":427,"ratings_complete":sum(r["ratings_complete"] for r in rows),
            "model":MODEL["model"],"judge":"arc:apex","cases":rows,
            "clinical_status":"awaiting confirmation","requirements_status":"awaiting confirmation"}
    save(ROOT / "STATUS.json",status)
    save(ROOT / "RESOURCE_USE.json",dict(resources))
    (ROOT / "RAW_OUTPUT.txt").write_text("\n".join(raw)+"\n")
    with (ROOT / "SCORES.csv").open("w") as f:
        writer=csv.DictWriter(f,fieldnames=list(scores[0]));writer.writeheader();writer.writerows(scores)
    with (ROOT / "COMPARISON.csv").open("w") as f:
        writer=csv.DictWriter(f,fieldnames=list(comparison[0]));writer.writeheader();writer.writerows(comparison)
    lines=["# Qwen3.8-27B: all current cases", "",f"Saved **{status['answers_complete']}/78 answers** and **{status['ratings_complete']}/427 item ratings**.","",
           "The 78 case/task groups retain their earlier audiences and conditions: 30 interviews and 48 written tasks. Interviews allow up to six questions. Clinical references and essential-information requirements remain **awaiting confirmation**.","",
           "Qwen is the answering model; arc:apex remains the judge. Old answers and scores are unchanged. The 35 recent tasks and the additional ten series tasks are included. Different task types and grading conditions are reported separately.","",
           "| Batch | Answers | Item ratings |", "|---|---:|---:|"]
    for batch in dict.fromkeys(r["batch"] for r in rows):
        rr=[r for r in rows if r["batch"]==batch]
        lines.append(f"| {batch} | {sum(r['answer_status']=='complete' for r in rr)}/{len(rr)} | {sum(r['ratings_complete'] for r in rr)}/{sum(len(r['criteria']) for r in rr)} |")
    lines += ["", "| Case | Mode | Answer | Grades |", "|---|---|---|---:|"]
    for r in rows:
        lines.append(f"| {r['case']} · {r['title']} | {r['mode']} | {r['answer_status']} | {r['ratings_complete']}/{len(r['criteria'])} |")
    lines += ["", "The original BMJ grading condition retains decision-window metadata; the 13-case and series batches use their selected evidence-only conditions. This collection does not repair that historical design difference.","",
              "[Full visible inputs, outputs, calls and grading explanations](RAW_OUTPUT.txt) · [Qwen scores and reasons](SCORES.csv) · [Historical models and Qwen by case/item](COMPARISON.csv) · [Frozen scope](MANIFEST.json)"]
    (ROOT / "RESULTS.md").write_text("\n".join(lines)+"\n")
    print("STATUS",status["answers_complete"],"/78 answers;",status["ratings_complete"],"/427 grades",flush=True)
    return status


def run(selected=None, wait=False):
    lock=(ROOT / ".run.lock").open("w")
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    manifest=verify()
    save(ROOT / "WORKER.json",{"pid":os.getpid(),"started_at":now(),"status":"running"})
    for batch in dict.fromkeys(r["batch"] for r in manifest["cases"]):
        t,target=load_batch(batch)
        cases=read(target / "cases.json")
        def partial_first(case):
            state=read(target / "answers" / MODEL["id"] / (case["id"]+".json"),{})
            if state.get("status")=="complete":
                missing=any(read(target/"grades"/MODEL["id"]/(case["id"]+"."+item+".json"),{}).get("status")!="complete" for item in case["criteria"])
                return 0 if missing else 3
            return 1 if state.get("turns") else 2
        cases.sort(key=partial_first)
        for case in cases:
            if selected and case["id"] not in selected:
                continue
            old=read(target / "answers" / MODEL["id"] / (case["id"]+".json"),{})
            if old.get("status")=="complete" and all(read(target/"grades"/MODEL["id"]/(case["id"]+"."+item+".json"),{}).get("status")=="complete" for item in case["criteria"]):
                continue
            while True:
                try:
                    save(ROOT / "WORKER.json",{"pid":os.getpid(),"status":"running","at":now(),"case":case["id"]})
                    state=written_answer(t,target,case) if case["mode"]=="written-record" else t.generate(case,MODEL)
                    grade_case(t,target,case,{**state,"model_slug":MODEL["id"]})
                    report()
                    break
                except Deferred as exc:
                    save(ROOT / "WORKER.json",{"pid":os.getpid(),"status":"waiting" if exc.wait else "needs_attention",
                         "at":now(),"case":case["id"],"reason":str(exc),"wait_seconds":round(exc.wait,2)})
                    report()
                    if not wait or not exc.wait:
                        return
                    print("WAIT",round(exc.wait,2),"seconds;",str(exc),flush=True)
                    time.sleep(min(exc.wait,60))
                except Exception as exc:
                    save(ROOT / "ERRORS" / (case["id"]+"."+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')+".json"),{"at":now(),"error":clean(str(exc))})
                    print("FAILED",case["id"],type(exc).__name__,clean(str(exc)),flush=True)
                    report()
                    break
    status=report()
    save(ROOT / "WORKER.json",{"pid":os.getpid(),"status":"complete" if status['ratings_complete']==427 else "partial", "finished_at":now()})
    verify()


if __name__ == "__main__":
    ap=argparse.ArgumentParser();ap.add_argument("phase",choices=["check","run","report"])
    ap.add_argument("--cases",nargs="+");ap.add_argument("--wait",action="store_true")
    args=ap.parse_args()
    if args.phase=="check":
        verify();print("PASS: 78 frozen cases, 427 planned ratings; historical files unchanged.")
    elif args.phase=="report":report()
    else:run(args.cases,args.wait)
