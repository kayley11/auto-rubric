"""Retry saved technical failures through Google's same-model compatible API.

Populate only the shared operation cache. Never write an answer or release a
fact, and never retry a completed output. Original messages must reconstruct the
entire captured native request exactly before any compatible call is made.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

import google_gemma
import prepare_inputs
import recovery_core as core
import run_generate


def original_messages(raw):
    native = raw['request']
    messages = []
    if native.get('systemInstruction'):
        messages.append({'role': 'system', 'content': ''.join(p['text'] for p in native['systemInstruction']['parts'])})
    for content in native['contents']:
        assert all(set(p) == {'text'} for p in content['parts']), 'Do not convert non-text evidence'
        messages.append({'role': 'assistant' if content['role'] == 'model' else content['role'],
                         'content': ''.join(p['text'] for p in content['parts'])})
    cap = native['generationConfig']['maxOutputTokens']
    assert google_gemma.make_request(messages, cap) == native, 'Native request cannot be reproduced exactly'
    assert core.digest(native) == raw['source_request_sha256'], 'Do not alter a saved request'
    return messages, cap


def recover(folder):
    try:
        raw = core.read(sorted(folder.glob('attempt_*.json'))[0])
        messages, cap = original_messages(raw)
        validator = run_generate.CONTROLLER.validate_question if '.question.' in folder.name else None
        core.request(folder.name, messages, max_tokens=cap, validator=validator)
        print('COMPAT_CACHE_READY', folder.name, flush=True)
        return {'operation': folder.name, 'status': 'cached', 'at': core.now()}
    except Exception as exc:
        print('COMPAT_CACHE_DEFERRED', folder.name, core.clean(str(exc))[:140], flush=True)
        return {'operation': folder.name, 'status': 'deferred', 'error': core.clean(str(exc)), 'at': core.now()}


def main():
    prepare_inputs.verify()
    run_generate.load_controller()
    core.GOOGLE_COMPAT = True
    visited = set()
    statuses = []
    while True:
        todo = []
        for folder in sorted((core.ROOT / 'calls/google').iterdir()):
            if not folder.is_dir() or folder.name in visited or (folder / 'COMPLETE.json').exists(): continue
            if not (folder.name.endswith('.final') or '.question.' in folder.name): continue
            if (core.ROOT / 'answers' / (folder.name.split('.')[0] + '.json')).exists(): continue
            attempts = [core.read(p) for p in folder.glob('attempt_*.json')]
            technical = [a for a in attempts if a.get('http_status') in {500, 503} or a.get('error_type') in {'ReadTimeout', 'ConnectTimeout'}]
            if len(technical) >= 3:
                todo.append(folder)
        if not todo:
            if (core.ROOT / 'GENERATION_FINISHED.json').exists(): break
            time.sleep(15)
            continue
        with ThreadPoolExecutor(max_workers=1) as pool:
            for folder in todo: visited.add(folder.name)
            for future in as_completed([pool.submit(recover, folder) for folder in todo]):
                statuses.append(future.result())
                core.save('COMPAT_CACHE_RECOVERY.json', {'updated_at': core.now(), 'rows': statuses,
                          'note': 'Same model, exact reconstructed request, shared cache and locks. Main generator alone writes answer records.'})


if __name__ == '__main__':
    main()
