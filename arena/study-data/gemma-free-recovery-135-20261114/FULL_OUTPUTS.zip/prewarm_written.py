"""Collect unchanged written-task calls while the main queue resumes interviews.

Only the shared append-only operation cache is populated. The main generator
remains the sole writer of complete answer records; the grading watcher consumes
those records. Per-operation locks and the shared minute budget prevent duplicate
model calls and quota multiplication across the two queues.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed

import prepare_inputs
import recovery_core as core


def collect(entry):
    cid = entry['case_id']
    source = core.read(core.ROOT / entry['generation_messages'])
    try:
        core.request(cid + '.final', source['messages'], max_tokens=source.get('max_tokens', 8192))
        print('WRITTEN_CALL_CACHED', cid, flush=True)
        return {'case_id': cid, 'status': 'cached'}
    except Exception as exc:
        print('WRITTEN_CALL_DEFERRED', cid, core.clean(str(exc))[:180], flush=True)
        return {'case_id': cid, 'status': 'deferred', 'error': core.clean(str(exc))}


def main():
    manifest = prepare_inputs.verify()
    rows = [c for c in manifest['cases'] if c['mode'] == 'written-record'
            and not (core.ROOT / 'answers' / (c['case_id'] + '.json')).exists()]
    statuses = []
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(collect, c) for c in rows]
        for future in as_completed(futures):
            statuses.append(future.result())
            core.save('PREWARM_WRITTEN_STATUS.json', {'updated_at': core.now(), 'total': len(rows),
                      'rows': statuses, 'note': 'Exact original written calls; only cache populated. No competing answer-record writer.'})


if __name__ == '__main__':
    main()
