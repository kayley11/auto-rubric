"""Key-local smoke test for Google's free, exact Gemma 4 31B endpoint.

No clinical task is sent by this command. Header credentials are never saved.
The same conversion functions can transport the frozen clinical messages once
the account's access has actually passed the smoke test.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import sys
import time
from uuid import uuid4

import httpx
from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parent
ENV_FILE = ROOT.parents[2] / "auto rubric/.env"
MODEL = "gemma-4-31b-it"
URL = "https://generativelanguage.googleapis.com/v1beta/models/" + MODEL + ":generateContent"
STREAM_URL = "https://generativelanguage.googleapis.com/v1beta/models/" + MODEL + ":streamGenerateContent?alt=sse"


def make_request(messages, max_tokens=256):
    """Preserve text and conversation order; translate transport roles only."""
    systems, contents = [], []
    for message in messages:
        text = message["content"]
        if not isinstance(text, str):
            raise ValueError("This recovery adapter supports text-only messages.")
        role = message["role"]
        if role == "system":
            if contents:
                raise ValueError("Cannot move a mid-conversation system instruction.")
            systems.append({"text": text})
        elif role in {"assistant", "user"}:
            contents.append({"role": "model" if role == "assistant" else "user", "parts": [{"text": text}]})
        else:
            raise ValueError("Unsupported source message role: " + role)
    if not contents or contents[-1]["role"] != "user":
        raise ValueError("Expected a user request at the end of the frozen conversation.")
    request = {
        "contents": contents,
        "generationConfig": {
            "temperature": 0, "topP": 1, "maxOutputTokens": max_tokens,
            "thinkingConfig": {"thinkingLevel": "minimal"},
        },
    }
    if systems:
        request["systemInstruction"] = {"parts": systems}
    return request


def final_text(response):
    """A successful HTTP response is not sufficient for a complete answer."""
    version = response.get("modelVersion", "")
    if version and MODEL not in version.lower():
        raise ValueError("Returned model version does not identify Gemma 4 31B: " + version)
    candidates = response.get("candidates", [])
    if len(candidates) != 1:
        raise ValueError("No unique candidate; inspect the preserved provider return.")
    candidate = candidates[0]
    if candidate.get("finishReason") != "STOP":
        raise ValueError("No complete final answer: " + str(candidate.get("finishReason")))
    parts = candidate.get("content", {}).get("parts", [])
    text = "".join(p.get("text", "") for p in parts if not p.get("thought"))
    if not text.strip():
        raise ValueError("No visible final answer.")
    return text


def sanitise(value, secrets):
    if isinstance(value, dict):
        return {k: sanitise(v, secrets) for k, v in value.items()
                if k.lower() not in {"authorization", "api_key", "x-goog-api-key", "cookie", "set-cookie"}}
    if isinstance(value, list):
        return [sanitise(v, secrets) for v in value]
    if isinstance(value, str):
        for secret in secrets:
            if secret:
                value = value.replace(secret, "[REDACTED]")
        return re.sub(r"\bAIza[\w-]{20,}", "[REDACTED]", value)
    return value


def read_stream(client, request, key):
    """Retain native SSE events and assemble only their documented text parts."""
    events, merged, candidates = [], {}, {}
    with client.stream("POST", STREAM_URL, headers={"x-goog-api-key": key}, json=request) as response:
        status, headers = response.status_code, dict(response.headers)
        if status != 200:
            response.read()
            try: return status, headers, response.json(), events
            except ValueError: return status, headers, {"unparsed_body": response.text}, events
        data = []
        def collect():
            if not data: return
            event = json.loads("\n".join(data)); events.append(event); data.clear()
            if "error" in event:
                merged["stream_error"] = event["error"]
            for field in ["modelVersion", "responseId", "usageMetadata", "promptFeedback"]:
                if field in event: merged[field] = event[field]
            for candidate in event.get("candidates", []):
                index = candidate.get("index", 0)
                target = candidates.setdefault(index, {"index": index, "content": {"role": "model", "parts": []}})
                target["content"]["parts"].extend(candidate.get("content", {}).get("parts", []))
                for field in ["finishReason", "safetyRatings", "finishMessage"]:
                    if field in candidate: target[field] = candidate[field]
        for line in response.iter_lines():
            if line.startswith("data:"):
                data.append(line[len("data:"):].lstrip())
            elif not line:
                collect()
        collect()
    merged["candidates"] = [candidates[i] for i in sorted(candidates)]
    return status, headers, merged, events


def smoke(stream=False):
    configured = dotenv_values(ENV_FILE)
    key = os.environ.get("GEMINI_API_KEY") or configured.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY") or configured.get("GOOGLE_API_KEY")
    if not key:
        print("GEMINI_API_KEY is not configured. No HTTP request sent; no answer or score added.")
        return 2
    key = key.strip()
    secrets = [v for k, v in configured.items() if v and any(s in k for s in ("KEY", "PASSWORD", "SECRET"))] + [key]
    messages = [{"role": "user", "content": "Reply with exactly OK."}]
    request = make_request(messages)
    result = {
        "checked_at": datetime.now(timezone.utc).isoformat(), "provider": "Google Gemini API",
        "endpoint": STREAM_URL if stream else URL, "requested_model": MODEL, "request": request,
        "paid_fallback": False, "ready_for_cases": False,
        "thinking": "minimal (disabled according to the Gemma API documentation)",
    }
    started = time.monotonic()
    try:
        with httpx.Client(timeout=httpx.Timeout(60, connect=10), trust_env=False, follow_redirects=False) as client:
            if stream:
                result["http_status"], _, result["response"], result["stream_events"] = read_stream(client, request, key)
            else:
                response = client.post(URL, headers={"x-goog-api-key": key}, json=request)
                result["http_status"] = response.status_code
                try: result["response"] = response.json()
                except ValueError: result["response"] = {"unparsed_body": response.text}
        if result["http_status"] != 200:
            raise ValueError("Google returned HTTP " + str(result["http_status"]))
        text = final_text(result["response"])
        result["visible_output"] = text
        result["ready_for_cases"] = text.strip() == "OK"
    except Exception as exc:
        result.update(error_type=type(exc).__name__, error=str(exc))
    result["seconds"] = round(time.monotonic() - started, 3)
    path = ROOT / ("GOOGLE_SMOKE_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + uuid4().hex[:8] + ".json")
    with path.open("x") as handle:
        json.dump(sanitise(result, secrets), handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    print(json.dumps(sanitise({k: v for k, v in result.items() if k not in {"request", "response"}}, secrets), ensure_ascii=False))
    print("Saved:", path.name)
    return 0 if result["ready_for_cases"] else 1


def check_offline():
    source = [{"role": "system", "content": "system\nunchanged"}, {"role": "user", "content": "old input"},
              {"role": "assistant", "content": "old answer"}, {"role": "user", "content": "new input"}]
    request = make_request(source, 8192)
    assert request["systemInstruction"]["parts"][0]["text"] == source[0]["content"]
    assert [(p["role"], p["parts"][0]["text"]) for p in request["contents"]] == [
        ("user", "old input"), ("model", "old answer"), ("user", "new input")]
    good = {"modelVersion": MODEL, "candidates": [{"finishReason": "STOP", "content": {
        "parts": [{"thought": True, "text": "excluded"}, {"text": "  saved final\n"}]}}]}
    assert final_text(good) == "  saved final\n"
    for response in [
        {"candidates": [{"finishReason": "MAX_TOKENS", "content": {"parts": [{"text": "partial"}]}}]},
        {"candidates": []},
        {"modelVersion": "gemma-4-26b-a4b-it", "candidates": good["candidates"]},
        {"candidates": [{"finishReason": "STOP", "content": {"parts": [{"thought": True, "text": "private"}]}}]},
    ]:
        try:
            final_text(response)
        except ValueError:
            pass
        else:
            raise AssertionError("Invalid/truncated/wrong-model output accepted")
    assert sanitise({"authorization": "secret", "error": "key123"}, ["key123"]) == {"error": "[REDACTED]"}
    print("Offline checks passed: text/roles preserved; partial, empty and wrong-model outputs rejected; secrets redacted. No HTTP calls made.")
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--smoke", action="store_true")
    group.add_argument("--smoke-stream", action="store_true")
    group.add_argument("--check-offline", action="store_true")
    args = parser.parse_args()
    sys.exit(check_offline() if args.check_offline else smoke(args.smoke_stream))
