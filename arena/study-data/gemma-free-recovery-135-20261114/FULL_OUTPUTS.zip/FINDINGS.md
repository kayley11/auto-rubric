# Gemma 4 31B: free-route checks and recovery inputs

**13 November 2026 — no new complete Gemma answers or scores have been added.** The current website has 135 Gemma answer slots without a complete answer. A Google API Key is needed to test the most promising additional free route.

## What the route checks found

| Route | Exact model | Free access | Result of this check | Next action |
|---|---|---|---|---|
| Google Gemini API, accessed directly | `gemma-4-31b-it` | Google's model documentation lists this model; its pricing page lists free input and output. | No Google API Key is configured locally, so no account-level inference test has been made. | Configure `GEMINI_API_KEY`; test one short response, then one original clinical task before starting the batch. |
| OpenRouter | `google/gemma-4-31b-it:free` | The selected endpoint has zero input/output prices. | HTTP 429: upstream **shared Google AI Studio pool** is rate limited. The endpoint list contains only this one free provider. | Retain the failed call; there is no second free provider in this route to select. |
| NVIDIA NIM | `google/gemma-4-31b-it` | NVIDIA advertises a free prototype endpoint. | The authenticated model list returns HTTP 200 and includes this exact model. Inference produced no answer: a normal request timed out after 35.1 seconds and a streaming request after 85.4 seconds. | Preserve the attempts. Listing the model does not establish usable inference; the timeout cause remains unconfirmed. |
| Hugging Face-maintained Space | `google/gemma-4-31b-it`, loaded as BF16 in the public source | Public ZeroGPU demo | A request using the published parameter bounds returned **“The requested GPU duration (360s) is larger than the maximum allowed.”** No answer was returned. | This anonymous demo route is not usable for the batch in the tested access state. |
| Requesty | `google/gemma-4-31b-it` | Its official free-model page lists this model, $0 tokens and 200 free requests/day. | No Requesty key is configured; inference was not tested. | A documented alternative if direct Google access cannot be used. The daily allowance is a request count, not a case count. |
| Local Ollama | `gemma4:31b` | No hosted inference fee; model download required | The official package is about 19 GB. This Mac has 24 GiB RAM and no Ollama runtime installed. Nothing was installed or downloaded. | Local quantised inference would need a separate fit/performance test and explicit serving/quantisation metadata. It is not a verified batch route. |

Google's direct endpoint uses the user's own project quota rather than OpenRouter's shared upstream pool. It may still be rate limited; successful access and the actual quota must be checked using this account. No numerical daily Google quota is assumed here.

Official sources: [Google model support](https://ai.google.dev/gemma/docs/core/gemma_on_gemini_api), [Google Gemma pricing](https://ai.google.dev/gemini-api/docs/pricing#gemma-4), [NVIDIA prototype](https://build.nvidia.com/google/gemma-4-31b-it/deploy), [OpenRouter providers](https://openrouter.ai/google/gemma-4-31b-it:free/providers), [Hugging Face Space](https://huggingface.co/spaces/huggingface-projects/gemma-4-31b-it), [Requesty free models](https://www.requesty.ai/models/free), [Ollama package](https://ollama.com/library/gemma4:31b).

## Inputs prepared for recovery

The separate [input manifest](INPUT_MANIFEST.json) freezes all **135 original cases/tasks**:

| Group | Cases/tasks | Original presentation retained |
|---|---:|---|
| Earlier library | 78 | 48 written tasks, 8 prepared interviews and 22 source-report interviews |
| New complex BMJ cases | 57 | 57 written tasks |
| Total | **135** | **105 written tasks and 30 interviews** |

All 105 written tasks retain their original system/user message text. The 30 interviews retain their six-question limit and original information-release rules. Researcher-only packets keep hidden outcomes separate from generation messages. File hashes were checked after preparation. No historical source file or result was changed.

These 135 tasks have 2,970 full-rubric item positions. That is not a promise of 2,970 numerical grades: a complete answer is required before grading, and genuine scope/evidence limitations must retain their distinct statuses.

## How the scores will be completed after access works

1. Test the exact 31B model using a short non-clinical request. Save the request, raw response, returned model version, finish status and any quota/error information.
2. Generate the missing answers from the frozen tasks. Preserve each complete final answer unchanged and retain every failed or truncated attempt. Do not silently substitute another model or a written condition for an interview.
3. Use the existing KCL `arc:apex` judge and full saved rubric. Keep D5c evidence separate from ordinary evidence scoring; withhold old scores and answering-model identity. List all 22 item positions and preserve justified non-numerical statuses.
4. Add only actual complete outputs to the website, with their new provider configuration identified. Keep earlier attempts, answers and grades available.

Clinical references and candidate necessary-information requirements remain **awaiting confirmation**.

## Saved evidence and checks

- [Current website Gemma inventory](WEBSITE_GEMMA_BASELINE.json): 135 missing complete answers; no numerical Gemma grades.
- [NVIDIA/OpenRouter checks](ROUTE_CHECK_20261113T153827Z.json).
- [NVIDIA streaming retry](NIM_STREAM_20261113T154225Z.json).
- [Hugging Face request using valid parameter bounds](HF_SMOKE_20261113T154520Z.json). The earlier 32-token test is retained separately; the public app requires at least 100 tokens, so that first test is not evidence of service availability.
- [Frozen 135-task inputs](INPUT_MANIFEST.json).
- [Google API smoke-test adapter](google_gemma.py): offline checks passed for role/text preservation, rejection of truncated/wrong-model returns, and credential redaction. Account-level access remains untested.

Create a key at [Google AI Studio](https://aistudio.google.com/api-keys), then add `GEMINI_API_KEY=your_key` to the local ignored `auto rubric/.env`, keeping the existing configuration. No payment or model fallback is enabled by these scripts. Do not put the key in a report, chat, export or repository.
