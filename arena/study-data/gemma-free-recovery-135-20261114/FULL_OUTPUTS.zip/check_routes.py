"""Check exact Gemma 4 31B free routes without altering any earlier attempt."""

import asyncio
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import time

import httpx
from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parent
CONFIG = dotenv_values(ROOT.parents[2] / "auto rubric/.env")
SECRETS = [
    value for key, value in CONFIG.items()
    if value and any(part in key.upper() for part in ("KEY", "TOKEN", "SECRET", "PASSWORD"))
]


def clean(value):
    if isinstance(value, dict):
        return {
            k: clean(v) for k, v in value.items()
            if k.lower() not in {"authorization", "cookie", "set-cookie", "api_key", "user_id"}
        }
    if isinstance(value, list):
        return [clean(v) for v in value]
    if isinstance(value, str):
        for secret in SECRETS:
            value = value.replace(secret, "[REDACTED]")
        return re.sub(r"\b(?:nvapi-|sk-or-v1-|gsk_|hf_)[A-Za-z0-9_-]{15,}", "[REDACTED]", value)
    return value


async def request(name, url, key_name=None, payload=None):
    headers = {"Accept": "application/json"}
    if key_name:
        if not CONFIG.get(key_name):
            return {"route": name, "status": "credential_not_configured"}
        headers["Authorization"] = "Bearer " + CONFIG[key_name]
    record = {
        "route": name, "url": url, "checked_at": datetime.now(timezone.utc).isoformat(),
        "request": payload, "paid_fallback": False, "ready_for_cases": False,
    }
    started = time.monotonic()
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(35, connect=10), trust_env=False) as client:
            response = await client.request("POST" if payload else "GET", url, json=payload, headers=headers)
        record["http_status"] = response.status_code
        record["rate_headers"] = {
            k: v for k, v in response.headers.items() if "ratelimit" in k or k == "retry-after"
        }
        try:
            body = response.json()
        except ValueError:
            body = {"response_text": response.text[:12000]}
        if name == "nim-model-directory" and response.status_code == 200:
            record["gemma_models"] = [m for m in body.get("data", []) if "gemma" in m.get("id", "").lower()]
        else:
            record["response"] = body
        record["status"] = "responded" if response.status_code == 200 else "limited" if response.status_code == 429 else "service_or_access_error"
        if payload and response.status_code == 200:
            choice = body.get("choices", [{}])[0]
            text = choice.get("message", {}).get("content") or ""
            if "<channel|>" in text:
                text = text.rsplit("<channel|>", 1)[-1]
            record["visible_output"] = text.strip()
            record["returned_model"] = body.get("model")
            cost = body.get("usage", {}).get("cost")
            record["reported_cost"] = cost
            record["ready_for_cases"] = (
                text.strip() == "OK"
                and choice.get("finish_reason") != "length"
                and (cost is None or float(cost) == 0)
                and "gemma-4-31b" in str(body.get("model", payload["model"])).lower()
            )
    except Exception as exc:
        record.update(status="transport_error", error_type=type(exc).__name__, error=str(exc))
    record["seconds"] = round(time.monotonic() - started, 3)
    return clean(record)


async def main():
    message = [{"role": "user", "content": "Reply with exactly OK."}]
    rows = await asyncio.gather(
        request("nvidia-nim", "https://integrate.api.nvidia.com/v1/chat/completions", "NVIDIA_API_KEY", {
            "model": "google/gemma-4-31b-it", "messages": message, "temperature": 0,
            "top_p": 1, "max_tokens": 256, "chat_template_kwargs": {"enable_thinking": False},
        }),
        request("openrouter-free", "https://openrouter.ai/api/v1/chat/completions", "OPENROUTER_API_KEY", {
            "model": "google/gemma-4-31b-it:free", "messages": message, "temperature": 0,
            "max_tokens": 256, "reasoning": {"enabled": False},
            "provider": {"allow_fallbacks": True, "max_price": {"prompt": 0, "completion": 0}},
        }),
        request("nim-model-directory", "https://integrate.api.nvidia.com/v1/models", "NVIDIA_API_KEY"),
        request("openrouter-free-endpoints", "https://openrouter.ai/api/v1/models/google/gemma-4-31b-it:free/endpoints"),
    )
    destination = ROOT / ("ROUTE_CHECK_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + ".json")
    destination.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for row in rows:
        print(json.dumps({k: row[k] for k in ("route", "status", "http_status", "ready_for_cases", "visible_output", "error_type", "seconds") if k in row}), flush=True)
    print("Saved", destination.name)


if __name__ == "__main__":
    asyncio.run(main())
