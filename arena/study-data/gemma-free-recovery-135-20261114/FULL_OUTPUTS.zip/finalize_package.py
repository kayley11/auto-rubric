"""Package the completed recovery without regenerating any result data."""
import csv
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile

import recovery_core as core

ROOT = core.ROOT
DELIVERY = ROOT.parents[1] / 'review/GEMMA_4_31B_RECOVERY_20261114'
SITE = ROOT.parents[2] / 'auto-rubric-public'


def main():
    summary = core.read(ROOT / 'RESULT_SUMMARY.json')
    validation = core.read(ROOT / 'VALIDATION.json')
    publication = core.read(ROOT / 'validation/LATEST_SITE_PUBLICATION.json')
    assert summary['answers_complete'] == summary['assessments_complete'] == 135
    assert validation['counts']['complete_profiles'] == 135 and not validation['missing_complete_answers']
    assert publication['status'] == 'succeeded' and publication['version_number'] == 47
    with (ROOT / 'ALL_ITEM_RESULTS.csv').open() as handle: rows = list(csv.DictReader(handle))
    assert len(rows) == 2970 and len({row['case_id'] for row in rows}) == 135
    assert sum(row['status'] == 'complete' for row in rows) == 2553
    assert not any(row['status'] in {'pending', 'no_complete_answer'} for row in rows)

    # Check built assets too; runtime credentials are not part of the public build.
    for path in (SITE / 'dist').rglob('*'):
        if path.is_file():
            blob = path.read_bytes()
            assert not any(secret.encode() in blob for secret in core.SECRETS), 'Credential in built output'

    readme = '''# Gemma 4 31B results — 14 November 2026

All 135 research tasks now have a complete Gemma output and a saved 22-item automated assessment. Gemma produced the answers through Google's free API; arc:apex / GLM-5.3 assessed them using the saved Full rubric and scoring context.

There are 2,553 numerical item grades, 247 not-applicable positions, 162 applicability decisions awaiting confirmation and 8 indeterminate assessments. No Gemma answer or automatic scoring operation remains unfinished.

| File | Contents |
|---|---|
| [FINDINGS.md](FINDINGS.md) | Method, coverage, technical checks and per-case status |
| [ALL_ITEM_RESULTS.csv](ALL_ITEM_RESULTS.csv) | All 2,970 item positions, scores, reasons and statuses |
| [RESULTS_BY_CASE.csv](RESULTS_BY_CASE.csv) | One row per case, including original format and API transport |
| [FULL_OUTPUTS.zip](FULL_OUTPUTS.zip) | Exact requests, received responses, attempts, fixed inputs, answers, all grading returns and validation evidence |
| [VALIDATION.json](VALIDATION.json) | Input, output, preservation and credential checks |
| [SITE_PUBLICATION.json](SITE_PUBLICATION.json) | Published version and website verification |

[Open the website](https://auto-rubric.kayley1026lzt.chatgpt.site/#cases). Choose a case, then click a score in **Gemma 4 31B · Google** to read its answer, rubric and saved judge reason.

Earlier answers, grades and raw records are retained. BN52's placeholder grading return is retained alongside its identical-input repair; its other valid item grades were unchanged. Clinical references and candidate information requirements remain **awaiting confirmation**.

The full archive includes researcher-only source and scoring snapshots. The public website contains the display copies. API keys and login passwords are excluded.
'''
    (ROOT / 'PACKAGE_README.md').write_text(readme)
    archive = ROOT / 'FULL_OUTPUTS.zip'
    manifest_path = ROOT / 'PACKAGE_MANIFEST.json'
    payloads = []
    for path in ROOT.rglob('*'):
        if not path.is_file() or path.is_symlink(): continue
        if path in {archive, manifest_path}: continue
        if '__pycache__' in path.parts or path.suffix in {'.pyc', '.lock', '.zip'}: continue
        if path.name in {'.DS_Store', 'ACTIVE.json'} or '.tmp.' in path.name or path.name.endswith('.tar.gz'): continue
        assert path.name != '.env' and not path.name.endswith('.env')
        blob = path.read_bytes()
        assert not any(secret.encode() in blob for secret in core.SECRETS), 'Credential in package file'
        assert not re.search(rb'(?:nvapi-[A-Za-z0-9_-]{20,}|sk-or-v1-[a-f0-9]{32,}|gsk_[A-Za-z0-9]{20,}|AIza[A-Za-z0-9_-]{20,}|AQ\.[A-Za-z0-9_-]{30,}|hf_[A-Za-z0-9]{20,})', blob), 'Credential-shaped value in package'
        payloads.append((path, hashlib.sha256(blob).hexdigest()))
    manifest = {'created_at': core.now(), 'files': {str(p.relative_to(ROOT)): h for p, h in payloads},
                'model_outputs': 135, 'full_profiles': 135, 'numerical_item_grades': 2553,
                'credentials_excluded': True, 'old_results_preserved': True}
    core.save(manifest_path, manifest)
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as out:
        for path, _ in payloads: out.write(path, str(path.relative_to(ROOT)))
        out.write(manifest_path, str(manifest_path.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as check: assert check.testzip() is None
    DELIVERY.mkdir(parents=True, exist_ok=True)
    copies = {'PACKAGE_README.md': 'README.md', 'RECOVERY_FINDINGS.md': 'FINDINGS.md',
              'ALL_ITEM_RESULTS.csv': 'ALL_ITEM_RESULTS.csv', 'RESULTS_BY_CASE.csv': 'RESULTS_BY_CASE.csv',
              'FULL_OUTPUTS.zip': 'FULL_OUTPUTS.zip', 'VALIDATION.json': 'VALIDATION.json',
              'validation/LATEST_SITE_PUBLICATION.json': 'SITE_PUBLICATION.json'}
    for source, name in copies.items(): shutil.copy2(ROOT / source, DELIVERY / name)
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == hashlib.sha256((DELIVERY / 'FULL_OUTPUTS.zip').read_bytes()).hexdigest()
    print(json.dumps({'delivery': str(DELIVERY), 'files': list(copies.values()),
                      'archive_files': len(payloads) + 1, 'archive_megabytes': round(archive.stat().st_size / 1e6, 2),
                      'answers': 135, 'assessments': 135, 'numerical_grades': 2553,
                      'website': publication['url'], 'version': publication['version_number']}, indent=2))


if __name__ == '__main__': main()
