"""Test Google's own alternative transport, never the OpenAI service."""
import json
import time
from datetime import datetime, timezone
import httpx
import recovery_core as core

URL = 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions'
request = {'model': 'gemma-4-31b-it', 'messages': [{'role': 'user', 'content': 'Reply with exactly OK.'}],
           'temperature': 0, 'top_p': 1, 'max_tokens': 256,
           'extra_body': {'google': {'thinking_config': {'thinking_level': 'minimal'}}}}
result = {'checked_at': core.now(), 'endpoint': URL, 'request': request, 'paid_fallback': False, 'ready_for_cases': False}
started = time.monotonic()
try:
    with httpx.Client(timeout=60, trust_env=False, follow_redirects=False) as client:
        response = client.post(URL, headers={'Authorization': 'Bearer ' + core.GOOGLE_KEY}, json=request)
    result['http_status'] = response.status_code
    result['response'] = response.json()
    if response.status_code == 200:
        data = result['response']; choice = data.get('choices', [{}])[0]
        result['ready_for_cases'] = 'gemma-4-31b-it' in data.get('model', '').lower() and choice.get('finish_reason') == 'stop' and choice.get('message', {}).get('content', '').strip() == 'OK'
except Exception as exc:
    result.update(error_type=type(exc).__name__, error=str(exc))
result['seconds'] = round(time.monotonic() - started, 3)
path = 'GOOGLE_COMPAT_' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '.json'
core.save(path, result)
print(json.dumps({k: v for k, v in result.items() if k not in ['request', 'response']}))
if not result['ready_for_cases']:
    print(json.dumps(core.clean(result.get('response', {})))[:1400])
