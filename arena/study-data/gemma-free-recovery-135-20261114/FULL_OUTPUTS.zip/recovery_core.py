"""Append-only provider calls for the exact free Gemma recovery condition."""
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import threading
import time
import math

import httpx
from dotenv import dotenv_values
import google_gemma

ROOT = Path(__file__).resolve().parent
MODEL = {"id": "gemma4-google", "model": "gemma-4-31b-it", "service": "google-free"}
ENV = dotenv_values(google_gemma.ENV_FILE)
SECRETS = [v for k, v in {**ENV, **os.environ}.items() if v and any(s in k for s in ("KEY", "PASSWORD", "SECRET"))]
GOOGLE_KEY = (os.getenv("GEMINI_API_KEY") or ENV.get("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY") or ENV.get("GOOGLE_API_KEY") or "").strip()
KCL_KEY = (os.getenv("OPENAI_API_KEY") or ENV.get("OPENAI_API_KEY") or "").strip()
KCL_BASE = (ENV.get("OPENAI_BASE_URL") or ENV.get("OPENAI_API_BASE") or "").rstrip("/").removesuffix("/chat/completions")
assert KCL_BASE.startswith("https://ai.create.kcl.ac.uk/"), "Only the existing authorised KCL endpoint may grade or route facts."
GOOGLE_SEM = threading.Semaphore(2)
KCL_SEM = threading.Semaphore(3)
GOOGLE_RATE_LOCK = threading.Lock()
GOOGLE_NEXT = 0
GOOGLE_STOP = None
KCL_STOP = None
GOOGLE_COMPAT = False
MAX_ATTEMPTS = 12
SAVE_LOCK = threading.RLock()


class Deferred(RuntimeError):
    pass


def now():
    return datetime.now(timezone.utc).isoformat()


def read(path, default=None):
    p = Path(path)
    return json.loads(p.read_text()) if p.exists() else default


def effective_grade(case_id):
    repaired = read(ROOT / 'grades_repaired' / (case_id + '.json'))
    return repaired if repaired is not None else read(ROOT / 'grades' / (case_id + '.json'))


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def clean(value):
    return google_gemma.sanitise(value, SECRETS)


def save(path, value):
    p = Path(path)
    if not p.is_absolute():
        p = ROOT / p
    p.parent.mkdir(parents=True, exist_ok=True)
    with SAVE_LOCK:
        tmp = p.with_suffix(p.suffix + ".tmp." + str(threading.get_ident()))
        tmp.write_text(json.dumps(clean(value), ensure_ascii=False, indent=2) + "\n")
        tmp.replace(p)


def freeze(path, value):
    p = ROOT / path
    if p.exists():
        assert read(p) == clean(value), "Frozen request changed: " + str(path)
    else:
        save(p, value)


def parse_json(text):
    return json.loads(re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip()))


def input_token_count(native):
    """Use the provider tokenizer; cache by the unchanged native request."""
    path = ROOT / 'token_counts' / (digest(native) + '.json')
    cached = read(path)
    if cached: return cached['reserved_input_tokens']
    body = {'generateContentRequest': {'model': 'models/' + google_gemma.MODEL, **native}}
    result = {'checked_at': now(), 'source_request_sha256': digest(native), 'request': body}
    try:
        with httpx.Client(timeout=30, trust_env=False) as client:
            response = client.post('https://generativelanguage.googleapis.com/v1beta/models/' + google_gemma.MODEL + ':countTokens',
                                   headers={'x-goog-api-key': GOOGLE_KEY}, json=body)
        result.update(http_status=response.status_code, response=response.json())
        tokens = result['response'].get('totalTokens') if response.status_code == 200 and isinstance(result['response'], dict) else None
        assert isinstance(tokens, int) and tokens > 0
        result.update(reserved_input_tokens=tokens, method='Google countTokens, full native request')
    except Exception as exc:
        tokens = math.ceil(len(json.dumps(native, ensure_ascii=False)) / 2) + 512
        result.update(reserved_input_tokens=tokens, method='conservative character estimate after tokenizer failure', error=str(exc))
    save(path, result)
    return tokens


def reserve_google_budget(tokens, oid):
    """Shared rolling-minute input-token budget, with a shared 429 cooldown."""
    assert tokens <= 14000, 'One input exceeds the safe free-tier minute budget; do not shorten or split clinical evidence silently.'
    folder = ROOT / 'provider_rate'; folder.mkdir(exist_ok=True)
    path = folder / 'google.json'
    announced = False
    while True:
        with (folder / 'google.lock').open('a+') as handle:
            fcntl.flock(handle, fcntl.LOCK_EX)
            state = read(path, {})
            tick = time.time()
            recent = [r for r in state.get('reservations', []) if r['at'] > tick - 61]
            wait = max(0, state.get('not_before', 0) - tick)
            if sum(r['tokens'] for r in recent) + tokens > 14000 or len(recent) >= 10:
                wait = max(wait, recent[0]['at'] + 61 - tick)
            if wait <= 0:
                recent.append({'at': tick, 'tokens': tokens, 'operation': oid})
                state.update(reservations=recent, observed_provider_input_tpm=16000, target_input_tpm=14000,
                             max_requests_per_minute=10, updated_at=now())
                save(path, state)
                fcntl.flock(handle, fcntl.LOCK_UN)
                return
            fcntl.flock(handle, fcntl.LOCK_UN)
        if not announced:
            print('GOOGLE_BUDGET_WAIT', oid, 'seconds', round(wait, 1), 'input_tokens', tokens, flush=True)
            announced = True
        time.sleep(min(wait + .25, 30))


def google_cooldown(seconds):
    folder = ROOT / 'provider_rate'; folder.mkdir(exist_ok=True)
    with (folder / 'google.lock').open('a+') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        path = folder / 'google.json'; state = read(path, {})
        state.update(not_before=max(state.get('not_before', 0), time.time() + seconds), updated_at=now())
        save(path, state)
        fcntl.flock(handle, fcntl.LOCK_UN)


def request(oid, messages, *, service="google", model=None, validator=None, max_tokens=8192, parameters=None):
    assert re.fullmatch(r"[\w.\-]+", oid), oid
    folder = ROOT / "operation_locks" / service
    folder.mkdir(parents=True, exist_ok=True)
    with (folder / (oid + ".lock")).open("a+") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        try:
            return _request_locked(oid, messages, service=service, model=model, validator=validator, max_tokens=max_tokens, parameters=parameters)
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def _request_locked(oid, messages, *, service="google", model=None, validator=None, max_tokens=8192, parameters=None):
    """Return the first technically valid output; never retry clinical content."""
    global GOOGLE_NEXT, GOOGLE_STOP, KCL_STOP
    assert re.fullmatch(r"[\w.\-]+", oid), oid
    if service == "google":
        model = google_gemma.MODEL
        endpoint, token = google_gemma.URL, GOOGLE_KEY
        payload = google_gemma.make_request(messages, max_tokens)
        sem = GOOGLE_SEM
    else:
        assert service == "kcl"
        model = model or "arc:apex"
        endpoint, token = KCL_BASE + "/chat/completions", KCL_KEY
        payload = {"model": model, "messages": messages, "temperature": 0, "top_p": 1,
                   "reasoning_effort": "low", "max_tokens": max_tokens,
                   "response_format": {"type": "json_object"}}
        if parameters:
            payload.update(parameters)
        sem = KCL_SEM
    assert token, service + " key missing"
    original = digest(payload)
    primary = ROOT / "calls" / service / oid
    cache = primary / "COMPLETE.json"
    if cache.exists():
        saved = read(cache)
        assert saved["source_request_sha256"] == original, "Cannot reuse a changed request"
        return saved["parsed"]
    source_payload = payload
    if service == "google" and GOOGLE_COMPAT:
        endpoint = 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions'
        payload = {"model": google_gemma.MODEL, "messages": messages, "temperature": 0, "top_p": 1, "max_tokens": max_tokens,
                   "extra_body": {"google": {"thinking_config": {"thinking_level": "minimal"}}}}
    base = ROOT / "calls" / ("google_compat" if service == "google" and GOOGLE_COMPAT else service) / oid
    base.mkdir(parents=True, exist_ok=True)
    previous = sorted(base.glob("attempt_*.json"))
    start = max([int(p.stem.split("_")[-1]) for p in previous], default=0)
    reserved_tokens = input_token_count(source_payload) if service == 'google' else None
    for attempt_number in range(start + 1, min(start + 4, MAX_ATTEMPTS + 1)):
        if (GOOGLE_STOP if service == "google" else KCL_STOP):
            raise Deferred(GOOGLE_STOP if service == "google" else KCL_STOP)
        cp = base / (f"attempt_{attempt_number:03}.json")
        capture = {"started_at": now(), "service": service, "endpoint": endpoint, "request": payload,
                   "source_request_sha256": original, "paid_fallback": False}
        if service == "google" and GOOGLE_COMPAT:
            capture["source_native_request"] = source_payload
            capture["transport"] = "Google OpenAI-compatible API; same messages and native minimal thinking configuration"
        started = time.monotonic()
        wait = 5
        try:
            with sem:
                if service == "google":
                    reserve_google_budget(reserved_tokens, oid)
                headers = {"x-goog-api-key": token} if service == "google" and not GOOGLE_COMPAT else {"Authorization": "Bearer " + token}
                save(base / "ACTIVE.json", {**capture, "pid": os.getpid(), "attempt_number": attempt_number})
                with httpx.Client(timeout=httpx.Timeout(240, connect=15), trust_env=False, follow_redirects=False) as client:
                    response = client.post(endpoint, headers=headers, json=payload)
            capture["http_status"] = response.status_code
            capture["rate_headers"] = {k: v for k, v in response.headers.items() if "ratelimit" in k or k == "retry-after"}
            try:
                raw = response.json()
            except ValueError:
                raw = {"unparsed_body": response.text}
            capture["response"] = raw
            if response.status_code != 200:
                if response.status_code in {400, 401, 402, 403, 404}:
                    message = service + " access/request rejected: HTTP " + str(response.status_code) + "; inspect preserved error. No paid fallback."
                    if service == "google": GOOGLE_STOP = message
                    else: KCL_STOP = message
                if response.status_code == 429:
                    rawtext = json.dumps(raw)
                    if service == "google" and re.search(r"(?:quotaId|quotaMetric)[^,\n]*(?:PerDay|per_day)", rawtext, re.I):
                        GOOGLE_STOP = "Google daily free quota reached; progress retained for an explicit later resume."
                    retry = re.search(r'"retryDelay"\s*:\s*"([\d.]+)s"', rawtext)
                    wait = max(15, float(retry.group(1)) + 1 if retry else 30)
                    try: wait = max(wait, float(response.headers.get("retry-after", "0")))
                    except ValueError: pass
                    if service == 'google': google_cooldown(wait + 2)
                raise RuntimeError(service + " HTTP " + str(response.status_code))
            if service == "google" and not GOOGLE_COMPAT:
                text = google_gemma.final_text(raw)
            else:
                if service == "google": assert google_gemma.MODEL in raw.get("model", "").lower(), "Returned model is not Gemma 4 31B"
                choice = raw["choices"][0]
                if choice.get("finish_reason") != "stop":
                    raise ValueError("Incomplete judge/matcher output: " + str(choice.get("finish_reason")))
                text = choice.get("message", {}).get("content")
                if not isinstance(text, str) or not text.strip():
                    raise ValueError("No visible judge/matcher output")
            parsed = validator(text) if validator else text
            capture.update(status="complete", seconds=round(time.monotonic() - started, 3), finished_at=now())
            save(cp, capture)
            save(cache, {"source_request_sha256": original, "selected_attempt": attempt_number,
                         "call_file": str(cp.relative_to(ROOT)), "parsed": parsed, "finished_at": now()})
            (base / "ACTIVE.json").unlink(missing_ok=True)
            return parsed
        except Exception as exc:
            capture.update(status="failed", error=str(exc), error_type=type(exc).__name__, seconds=round(time.monotonic() - started, 3), finished_at=now())
            save(cp, capture)
            (base / "ACTIVE.json").unlink(missing_ok=True)
            print("CALL_FAILED", service, oid, attempt_number, clean(str(exc))[:160], flush=True)
            if (GOOGLE_STOP if service == "google" else KCL_STOP):
                raise Deferred(GOOGLE_STOP if service == "google" else KCL_STOP) from exc
            # Recover only token truncation; the clinical input stays unchanged.
            if "MAX_TOKENS" in str(exc) or "length" in str(exc):
                if service == "google" and not GOOGLE_COMPAT:
                    payload["generationConfig"]["maxOutputTokens"] = min(32768, max_tokens * 2)
                else:
                    payload["max_tokens"] = max(16384, max_tokens)
            if attempt_number < min(start + 3, MAX_ATTEMPTS):
                time.sleep(min(wait, 60))
    raise RuntimeError("No technically valid saved output after bounded attempts: " + oid)
