"""Freeze original Gemma tasks for recovery; never mutate a historical run.

This prepares inputs only. It does not generate answers or assign scores.
"""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUNS = ROOT.parent
ORIGINAL = RUNS / "gemma_nim_78_cases_20261103"
COMPLEX = RUNS / "complex_bmj_all_models_20261112"
AUDIT = RUNS / "na_scope_audit_135_20261112"
ITEMS = ["D1", "D2a", "D2b", "D2c", "D2d", "D3a", "D3b", "D3c", "D3d",
         "D4a", "D4b", "D4c", "D4d", "D5u", "D5b", "D5c", "D6a", "D6b", "D6c",
         "D7a", "D7b", "D7c"]


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_once(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    content = data if isinstance(data, bytes) else (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode()
    if path.exists():
        if path.read_bytes() != content:
            raise ValueError("Frozen input differs: " + str(path))
    else:
        with path.open("xb") as handle:
            handle.write(content)


def verify():
    manifest = read(ROOT / "INPUT_MANIFEST.json")
    for path, digest in manifest["frozen_sha256"].items():
        if sha(ROOT / path) != digest:
            raise ValueError("Frozen recovery input changed: " + path)
    assert len(manifest["cases"]) == len({c["case_id"] for c in manifest["cases"]}) == 135
    assert Counter(c["mode"] for c in manifest["cases"]) == {
        "prepared-interview": 8, "source-interview": 22, "written-record": 105}
    assert sum(bool(c.get("generation_messages")) for c in manifest["cases"]) == 105
    assert set(read(ROOT / "sources/FULL_RUBRIC.json")["criteria"][i]["id"] for i in range(22)) == set(ITEMS)
    return manifest


def main():
    if (ROOT / "INPUT_MANIFEST.json").exists():
        manifest = verify()
        print("Frozen recovery inputs verified:", manifest["case_count"], "cases;", manifest["mode_counts"])
        return

    source_hashes, frozen_hashes, rows = {}, {}, []

    def copy(source, destination):
        relative = "sources/" + destination
        write_once(ROOT / relative, source.read_bytes())
        source_hashes[str(source.relative_to(RUNS))] = sha(source)
        frozen_hashes[relative] = sha(ROOT / relative)
        return relative

    original = read(ORIGINAL / "MANIFEST.json")
    for relative, digest in original["frozen_hashes"].items():
        assert sha(ORIGINAL / relative) == digest, relative
    copy(ORIGINAL / "MANIFEST.json", "original78/MANIFEST.json")
    for cohort in sorted({c["batch"] for c in original["cases"]}):
        folder = ORIGINAL / "cohorts" / cohort
        for filename in ("cases.json", "protocol.json", "source_protocol.json", "rubric_snapshot.json",
                         "GRADE_SELECTION.json", "topics.json", "interview_prompts.json", "written_messages.json"):
            if (folder / filename).exists():
                copy(folder / filename, "original78/" + cohort + "/" + filename)
        cases = {c["id"]: c for c in read(folder / "cases.json")}
        written = read(folder / "written_messages.json")
        for entry in [c for c in original["cases"] if c["batch"] == cohort]:
            case = cases[entry["case"]]
            mode = case["mode"]
            record = {
                "case_id": case["id"], "cohort": cohort, "title": case["title"],
                "audience": case["audience"], "mode": mode,
                "researcher_case_file": "sources/original78/" + cohort + "/cases.json",
                "protocol_file": "sources/original78/" + cohort + "/protocol.json",
                "original_selected_items": case["criteria"], "full_rubric_items": ITEMS,
            }
            if mode == "written-record":
                assert case["id"] in written
                relative = "requests/generation/" + case["id"] + "__original_messages.json"
                write_once(ROOT / relative, {"messages": written[case["id"]]})
                frozen_hashes[relative] = sha(ROOT / relative)
                record["generation_messages"] = relative
            else:
                assert mode in {"prepared-interview", "source-interview"}
                record.update(max_questions=6, information_release="Original fixed-fact controller; no hidden outcome is supplied to the answerer.")
            rows.append(record)

    for case_file in sorted((COMPLEX / "packets").glob("BN*.json")):
        case = read(case_file)
        assert case["id"] == case_file.stem
        packet = copy(case_file, "complex57/packets/" + case_file.name)
        request = COMPLEX / "requests/generation" / (case["id"] + "__gemma4-nim.json")
        destination = copy(request, "complex57/requests/" + request.name)
        body = read(request)
        user = json.loads(body["messages"][1]["content"])
        assert user["CASE_INFORMATION"] == case["visible"]
        assert set(user) == {"DECISION_POINT", "CASE_INFORMATION", "TASK"}
        rows.append({
            "case_id": case["id"], "cohort": "complex57", "title": case["title"],
            "audience": case["audience"], "mode": "written-record",
            "researcher_case_file": packet, "generation_messages": destination,
            "full_rubric_items": ITEMS,
        })

    copy(COMPLEX / "SOURCE_RUBRIC.json", "FULL_RUBRIC.json")
    copy(COMPLEX / "COMMON_PROTOCOL.json", "complex57/COMMON_PROTOCOL.json")
    copy(AUDIT / "CASE_INPUTS.json", "scope_audit/CASE_INPUTS_RESEARCHER_ONLY.json")
    # Preserve controller source versions for a later resumed interview run.
    for relative in ("qwen_all_cases_20261101/run.py", "five_model_33_cases_20261029/run.py",
                     "five_model_33_cases_20261029/patient_matching.py",
                     "complex_bmj_all_models_20261112/engine_core.py"):
        source = RUNS / relative
        if source.exists():
            copy(source, "controllers/" + relative)

    assert len(rows) == len({r["case_id"] for r in rows}) == 135
    manifest = {
        "prepared_at": datetime.now(timezone.utc).isoformat(), "case_count": 135,
        "case_groups": {"original78": 78, "complex57": 57},
        "mode_counts": dict(Counter(r["mode"] for r in rows)), "cases": rows,
        "source_sha256": source_hashes, "frozen_sha256": frozen_hashes,
        "model_required": "Gemma 4 31B IT, not another Gemma size or a fine-tuned derivative",
        "generation_service_status": "No working free route verified for this account yet",
        "clinical_references": "awaiting confirmation", "information_requirements": "awaiting confirmation",
        "recovery_policy": {
            "historical_results": "Read-only; new raw calls, attempts, complete answers and grades go under this separate run.",
            "written_tasks": "Preserve exact source system/user message text; transport roles may be converted for a native API.",
            "interviews": "Retain the original six-question limit and information-release controller; never substitute a full written vignette silently.",
            "grading": "Use the full saved rubric and the existing KCL arc:apex judge. Assess D5c separately; withhold answer-model identity, old grades and hidden outcomes from ordinary evidence scoring.",
            "scope": "List all 22 item positions. Do not replace not applicable, applicability awaiting confirmation, or indeterminate states with invented numerical grades.",
            "cost": "No payment, recharge, paid model fallback, or automatic change of model.",
        },
    }
    write_once(ROOT / "INPUT_MANIFEST.json", manifest)
    verify()
    print("Frozen:", len(rows), "cases;", manifest["mode_counts"], "; 105 exact written-message packets; 30 original interview protocols.")


if __name__ == "__main__":
    main()
