"""Build inspectable recovery results and a safe additive website data overlay."""
import argparse
from collections import Counter
from copy import deepcopy
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import zipfile

import prepare_inputs
import recovery_core as core

ROOT = core.ROOT
SITE = ROOT.parents[2] / "auto-rubric-public"
ARENA = ROOT.parents[2] / "auto rubric/arena"
BASE = ROOT / "website_before"
OUT = ROOT / "website_update"
spec = importlib.util.spec_from_file_location("recovery_word_count", ROOT.parent / "full_rubric_completion_78_20261104/complete.py")
COUNTS = importlib.util.module_from_spec(spec)
spec.loader.exec_module(COUNTS)


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def md(s):
    return str(s).replace("|", "\\|").replace("\n", " ")


def freeze_baseline():
    manifest_file = ROOT / "WEBSITE_BEFORE_MANIFEST.json"
    if manifest_file.exists():
        manifest = core.read(manifest_file)
        for path, expected in manifest.items(): assert sha(BASE / path) == expected, path
        return manifest
    paths = []
    for folder in ("full-rubric-review", "complex-cases"):
        paths += list((SITE / "public" / folder).glob("*.json"))
        paths += list((SITE / "public" / folder).glob("*.md"))
    for p in paths:
        rel = p.relative_to(SITE / "public")
        dest = BASE / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, dest)
    manifest = {str(p.relative_to(BASE)): sha(p) for p in BASE.rglob("*") if p.is_file()}
    core.freeze("WEBSITE_BEFORE_MANIFEST.json", manifest)
    return manifest


def new_model(entry, record, old):
    cid = entry["case_id"]
    answer = core.read(ROOT / "answers" / (cid + ".json"))
    grade = core.effective_grade(cid)
    plan = core.read(ROOT / "plans" / (cid + ".json"))
    if grade: assert answer and grade["answer_sha256"] == core.digest(answer["final_answer"])
    if grade:
        scores = deepcopy(grade["scores"])
    else:
        scores = [{"item": i, "status": "no_complete_answer" if not answer else plan["scope"][i]["status"] if plan["scope"][i]["status"] != "applicable" else "pending",
                   "score": None, "reason": "No complete Gemma answer has been saved for this task." if not answer else
                   plan["scope"][i]["reason"] if plan["scope"][i]["status"] != "applicable" else "The saved Gemma answer is waiting for its automatic Full rubric assessment.",
                   "evidence_quote": "", "review_flags": []} for i in prepare_inputs.ITEMS]
    for row in scores:
        row["label"] = str(row["score"]) if row.get("score") is not None else None
    turns = []
    for t in (answer or {}).get("turns", []):
        turns.append({"number": t["number"], "question": t["question"], "assessment": t.get("assessment", {}),
                      "returned": [{k: f.get(k, "") for k in ("id", "channel", "patient_text", "text", "context", "period")} for f in t.get("returned", [])],
                      "feedback": t.get("feedback", "")})
    text = (answer or {}).get("final_answer", "")
    selected_calls = []
    cache_files = list((ROOT / 'calls/google').glob(f'{cid}.question.*/COMPLETE.json')) + [ROOT / 'calls/google' / f'{cid}.final' / 'COMPLETE.json']
    for cache_file in cache_files:
        call = core.read(cache_file)
        if call:
            raw = core.read(ROOT / call['call_file'])
            selected_calls.append('Google compatible API' if raw.get('source_native_request') else 'Google native API')
    transports = sorted(set(selected_calls))
    result = {"id": "gemma4-google", "name": "Gemma 4 31B · Google", "model_id": "gemma-4-31b-it", "backend_model": "", "service": "google-free",
              "provider_transports": transports,
              "answer_status": "complete" if answer else "no_complete_answer", "answer": text,
              "word_count": COUNTS.word_count(text, record["task"]) if answer else None,
              "turns": turns, "closing_note": (answer or {}).get("closing_note"), "scores": scores,
              "ratings_complete": sum(s["status"] == "complete" for s in scores),
              "not_applicable_count": sum(s["status"] == "not_applicable" for s in scores),
              "indeterminate_count": sum(s["status"] == "indeterminate" for s in scores),
              "judge": "arc:apex / GLM-5.3", "rule_version": record["rule_version"],
              "study_id": "gemma-free-recovery-135-20261114", "scoring_condition": "full-rubric-with-retained-scope-audit",
              "comparison_note": "Collected separately on 14 Nov 2026 through Google's free Gemma API, with thinking disabled. The original task and presentation were retained. Existing answers and grades from other models are unchanged. References and candidate information requirements are awaiting confirmation.",
              "prior_unavailable_configuration": deepcopy(old), "repeats": [],
              "judge_outputs": {k: p["raw_parsed"] for k, p in (grade or {}).get("parts", {}).items()}}
    if grade and grade.get('technical_repairs'):
        result['technical_grade_repairs'] = [{k: repair[k] for k in ['phase', 'items', 'reason']} for repair in grade['technical_repairs']]
        result['comparison_note'] += ' An uninformative placeholder grading response was repeated with identical scoring input; original outputs and other valid item grades are retained.'
    return result


def plain(record):
    m = next(m for m in record["models"] if m["id"] == "gemma4-google")
    lines = [f'# {record["id"]} — {record["title"]}', '',
             'Answer model: Gemma 4 31B IT · Google Gemini API · free endpoint · thinking disabled',
             'Scoring model: arc:apex / GLM-5.3', 'Clinical references and information requirements: awaiting confirmation.', '',
             '## Case information actually supplied', '', record["initial_facts"], '', '## Original task', '', record["task"]]
    for t in m["turns"]:
        lines += ['', f'## Question {t["number"]}', '', t["question"], '', 'Saved assessment note before the reply:',
                  json.dumps(t["assessment"], ensure_ascii=False), '', 'Information actually returned:']
        lines += [f'{f["id"]} [{f.get("channel", "")}; {f.get("context") or f.get("period", "")}]: {f.get("patient_text") or f.get("text", "")}' for f in t["returned"]]
        lines += ['', 'Environment feedback: ' + t["feedback"]]
    lines += ['', '## Saved final answer', '', m["answer"] or 'No complete answer saved.', '', '## Full rubric assessment', '']
    names = {c["id"]: c["name"] for c in record["criteria"]}
    for s in m["scores"]:
        label = s["label"] if s.get("label") is not None else s["status"].replace('_', ' ')
        lines += [f'### {s["item"]} — {names[s["item"]]}: {label}', '', s["reason"]]
        if s.get("evidence_quote"): lines += ['', 'Judge-supplied excerpt: ' + s["evidence_quote"]]
        if s.get("requirement_checks"): lines += ['', 'Candidate requirement checks:', json.dumps(s["requirement_checks"], ensure_ascii=False, indent=2)]
    return '\n'.join(lines) + '\n'


def build(copy_to_site=False, archive=False):
    manifest = prepare_inputs.verify()
    baseline = freeze_baseline()
    summary, itemrows, fulltext = [], [], []
    totals, groups = Counter(), {}
    for entry in manifest["cases"]:
        cid = entry["case_id"]
        folder = "complex-cases" if entry["cohort"] == "complex57" else "full-rubric-review"
        record = core.read(BASE / folder / (cid + ".json"))
        originals = [m for m in record["models"] if "gemma" not in m["id"]]
        old = next(m for m in record["models"] if "gemma" in m["id"])
        assert not old.get("answer") and not any(s.get("score") is not None for s in old["scores"]), "Do not replace a prior successful Gemma result"
        model = new_model(entry, record, old)
        record["models"] = [model if m["id"] == old["id"] else m for m in record["models"]]
        assert [m for m in record["models"] if "gemma" not in m["id"]] == originals
        # The authoritative protocol distinguishes the 30 historical interviews.
        record["mode"] = "written-record" if entry["mode"] == "written-record" else "interview"
        record["max_questions"] = 0 if entry["mode"] == "written-record" else 6
        record["authoritative_execution_mode"] = entry["mode"]
        record["updated_at"] = core.now()
        record["gemma_recovery"] = {"date": "14 Nov 2026", "report": "/gemma-recovery/FINDINGS.md", "historical_results_retained": True}
        core.save(OUT / folder / (cid + ".json"), record)
        text = plain(record)
        core.save(OUT / "gemma-recovery" / (cid + ".json"), {k: record[k] for k in ["id", "title", "task", "initial_facts", "mode", "max_questions", "criteria", "clinical_status", "requirements_status"]} | {"model": model})
        p = OUT / "gemma-recovery" / (cid + ".md")
        p.write_text(text)
        fulltext.append(text)
        counts = Counter(s["status"] for s in model["scores"])
        totals.update(counts)
        row = {"case_id": cid, "title": entry["title"], "cohort": entry["cohort"], "mode": entry["mode"], "provider_transports": ', '.join(model['provider_transports']),
               "answer_status": model["answer_status"], "assessment_status": "complete" if (ROOT / "grades" / (cid + ".json")).exists() else "not_yet_assessed",
               "turns": len(model["turns"]), "words": (model["word_count"] or {}).get("words"), **dict(counts)}
        summary.append(row); groups.setdefault(folder, []).append(record)
        for score in model["scores"]:
            itemrows.append({"case_id": cid, "mode": entry["mode"], "answer_model": "Gemma 4 31B IT", "provider": "Google Gemini API",
                             "provider_transports": ', '.join(model['provider_transports']),
                             "judge": "arc:apex / GLM-5.3", "item": score["item"], "status": score["status"], "score": score.get("score"),
                             "reason": score["reason"], "evidence_quote": score.get("evidence_quote", ""),
                             "clinical_status": "awaiting confirmation"})
    answers = sum(r["answer_status"] == "complete" for r in summary)
    assessments = sum(r["assessment_status"] == "complete" for r in summary)
    overview = {"updated_at": core.now(), "case_count": 135, "answers_complete": answers, "assessments_complete": assessments,
                "item_statuses": dict(totals), "cases": summary, "clinical_status": "awaiting confirmation", "requirements_status": "awaiting confirmation"}
    core.save("RESULT_SUMMARY.json", overview)
    core.save(OUT / "gemma-recovery/index.json", overview)
    for folder, records in groups.items():
        index = core.read(BASE / folder / "index.json")
        allscores = [s for r in records for m in r["models"] for s in m["scores"]]
        allmodels = [m for r in records for m in r["models"]]
        index["updated_at"] = core.now()
        index["gemma_recovery"] = {"date": "14 Nov 2026", "report": "/gemma-recovery/FINDINGS.md", "complete_answers": sum(m["answer_status"] == "complete" for m in allmodels if m["id"] == "gemma4-google")}
        index["item_statuses"] = dict(Counter(s["status"] for s in allscores))
        if folder == "full-rubric-review":
            index["complete_answers"] = sum(m["answer_status"] == "complete" for m in allmodels)
            index["missing_answers"] = len(allmodels) - index["complete_answers"]
        else:
            index["completed_answers"] = sum(m["answer_status"] == "complete" for m in allmodels)
            index["completed_evaluations"] = sum(all(s["status"] not in {"no_complete_answer", "pending"} for s in m["scores"]) for m in allmodels)
        bycase = {r["id"]: r for r in records}
        for row in index["cases"]:
            record = bycase[row["id"]]
            if "status_counts" in row:
                row["status_counts"] = dict(Counter(s["status"] for m in record["models"] for s in m["scores"]))
            if "models" in row:
                row["models"] = [{"id": m["id"], "answer_status": m["answer_status"], "items_assessed": sum(s["status"] not in {"pending", "no_complete_answer"} for s in m["scores"]), "numerical_scores": m["ratings_complete"]} for m in record["models"]]
        core.save(OUT / folder / "index.json", index)
    for name, rows in [("ALL_ITEM_RESULTS.csv", itemrows), ("RESULTS_BY_CASE.csv", summary)]:
        fields = list(dict.fromkeys(k for r in rows for k in r))
        with (ROOT / name).open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader(); writer.writerows(rows)
        shutil.copy2(ROOT / name, OUT / "gemma-recovery" / name)
    status = "All 135 tasks have a complete Gemma output and a saved 22-item automated assessment. Clinical and applicability confirmation remain separate." if assessments == 135 else f'{answers}/135 complete answers; {assessments}/135 complete assessments. Remaining cells are labelled explicitly.'
    lines = ['# Gemma 4 31B: recovered answers and Full rubric assessments', '', status, '',
             "Google's direct free Gemma API returned complete responses after the previously tested OpenRouter and NVIDIA routes failed. All earlier results are retained. Clinical references and candidate information requirements remain **awaiting confirmation**.", '',
             '## Free route verified', '',
             'The working route is the [Google Gemma API](https://ai.google.dev/gemma/docs/core/gemma_on_gemini_api). Google lists Gemma 4 input and output as free in its [API pricing](https://ai.google.dev/gemini-api/docs/pricing#gemma-4). The exact returned model ID is checked before an output is accepted.', '',
             '| Route checked | Observed result | Used for this recovery |', '|---|---|---|',
             '| Google direct API, own key | Successful exact-model and clinical responses | Yes |',
             '| Google compatible API, own key | Successful exact-model and clinical responses; transport saved per case | Yes, where recorded |',
             '| OpenRouter free shared route | HTTP 429 on the latest probe | No |',
             '| NVIDIA NIM | Latest inference probe timed out; no complete pilot answer | No |',
             '| KCL model catalogue | No Gemma 4 31B deployment listed on 14 November | No |', '',
             '## What was held fixed', '', 'The 135 original cases/tasks were retained: 105 written tasks and 30 interviews (8 prepared cases and 22 source-report cases). Written generation reused the exact saved messages. Interviews retained six question opportunities and the existing fixed-fact release controller. Presentation labels now follow the frozen protocol. Hidden outcomes were not supplied to the answering model.', '',
             'The new answering configuration is `gemma-4-31b-it` through the Google Gemini API, temperature 0, top-p 1 and thinking disabled (`minimal`). This is a separate provider run. The scoring model remains `arc:apex` / GLM-5.3 with the saved full Overleaf rubric. Original-cohort judge sampling settings are retained: earlier 78 at 0.7/0.8; complex BN at 0/1. New technical output schemas constrain JSON fields and legal categories without changing clinical definitions.', '',
             'Both tested Google transports are recorded per case: the native API and Google\'s own compatible API. Both are served by Google with the same model, messages and thinking configuration. The local raw calls preserve the selected transport and every unsuccessful attempt.', '',
             'For the earlier 78 tasks, the main scoring record contains the actual case/task, received evidence and unchanged final answer. For the 57 BN tasks, the saved scoring-only safety key and three observation checks are also retained. These guides can name undisclosed outcomes as examples of what the judge must not require; they were not given to the answering model. D5c is assessed separately with the frozen candidate checklist. Scope decisions follow the 12 November audit: clear omissions are assessed, genuine exclusions remain N/A, and unresolved applicability remains awaiting confirmation.', '',
             '## Coverage', '', '| Result | Count |', '|---|---:|', f'| Complete answers | {answers}/135 |', f'| Complete Full rubric profiles | {assessments}/135 |']
    for key in ['complete', 'not_applicable', 'applicability_pending', 'indeterminate', 'pending', 'no_complete_answer']:
        lines.append(f'| {key.replace("_", " ")} item positions | {totals[key]} |')
    lines += ['', 'There are 2,970 item positions, not necessarily 2,970 numerical grades. Provider failure, an unscored answer, uncertain applicability and insufficient assessment evidence have different statuses.', '',
              '## Technical checks', '', 'Every completed profile has all 22 item positions. Numerical grades use only the saved allowed categories, including 1/3/5-only items. Non-numerical positions have null scores and a specific reason. Judge excerpts are retained as returned and checked against the unchanged final answer; unmatched excerpts are flagged rather than silently rewritten.', '',
              'Transient Google 500/503 errors and unsuccessful format returns are saved. An initially network-restricted prefetch worker also produced local DNS failures; it was restarted with authorised network access. Those failures are environmental errors, not model refusals. Incomplete outputs receive no clinical grade. A grading-queue restart is documented; completed files were preserved and interprocess locks now prevent overlapping work. No paid model or another Gemma size was substituted.', '',
              'The account returned a free-tier input limit of 16,000 tokens per minute. A shared scheduler uses a conservative 14,000-token budget, counts complete prompts through Google\'s tokenizer and respects retry delays. Recovery permits up to 12 technical attempts per operation and transport, with at most three new attempts per pass. Both Google transports share the same success cache and operation lock, so a completed output is reused rather than regenerated. Completed answers and valid grades are never retried to obtain different content or scores. These recovered results therefore do not constitute a single-attempt availability or speed comparison.', '',
              '## Case-by-case status', '', '| Case | Original format | Answer | Full profile | Numerical grades | Awaiting applicability confirmation |', '|---|---|---|---|---:|---:|']
    repairs = [(e['case_id'], core.effective_grade(e['case_id'])) for e in manifest['cases']]
    repaired = [(cid, g) for cid, g in repairs if g and g.get('technical_repairs')]
    if repaired:
        lines[lines.index('## Technical checks') + 2:lines.index('## Technical checks') + 2] = [
            'A judge response containing literal placeholders is a non-assessment, not a clinical finding of insufficient evidence. ' +
            '; '.join(f'{cid}: {sum(len(p["items"]) for p in g["technical_repairs"])} placeholder items replaced after an identical-input grading retry' for cid, g in repaired) +
            '. Original files and all other valid item grades are unchanged; both returns remain available in the saved output.', '']
    for r in summary:
        lines.append(f'| {r["case_id"]} | {r["mode"]} | {r["answer_status"]} | {r["assessment_status"]} | {r.get("complete", 0)} | {r.get("applicability_pending", 0)} |')
    lines += ['', '## Files', '', '[All item grades and reasons](ALL_ITEM_RESULTS.csv) · [Per-case status](RESULTS_BY_CASE.csv). Full local provider calls, failures and original input snapshots are retained in this run. The website receives visible case/answer/assessment copies only, without credentials or provider envelopes.']
    text = '\n'.join(lines) + '\n'
    (ROOT / "RECOVERY_FINDINGS.md").write_text(text)
    (OUT / "gemma-recovery/FINDINGS.md").write_text(text)
    (ROOT / "FULL_VISIBLE_OUTPUTS.md").write_text('\n\n'.join(fulltext))
    if copy_to_site:
        for p in OUT.rglob("*"):
            if not p.is_file(): continue
            relative = p.relative_to(OUT)
            dest = SITE / "public" / relative
            # Fail on unrelated concurrent source edits instead of replacing them.
            if str(relative) in baseline and dest.exists():
                old = core.read(BASE / relative) if dest.suffix == '.json' else (BASE / relative).read_text()
                current = core.read(dest) if dest.suffix == '.json' else dest.read_text()
                if current != old:
                    if not (isinstance(current, dict) and current.get('gemma_recovery')):
                        raise ValueError('Concurrent non-recovery website edit: ' + str(relative))
                    if 'models' in old:
                        assert [m for m in current['models'] if 'gemma' not in m['id']] == [m for m in old['models'] if 'gemma' not in m['id']], 'Concurrent edit to another model'
                        for field in ['task', 'initial_facts', 'reference', 'requirements', 'criteria', 'title', 'source_url', 'source_location']:
                            assert current.get(field) == old.get(field), 'Concurrent edit to case material: ' + field
            dest.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(p, dest)
            canonical = ARENA / 'public' / relative
            canonical.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(p, canonical)
    if archive:
        path = ROOT / 'FULL_OUTPUTS.zip'
        with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED) as z:
            for p in ROOT.rglob('*'):
                if not p.is_file() or p == path or '__pycache__' in p.parts or p.suffix == '.lock' or p.name == 'ACTIVE.json' or '.tmp.' in p.name or p.name.endswith('.tar.gz'): continue
                z.write(p, str(p.relative_to(ROOT)))
    print(json.dumps({k: overview[k] for k in ['case_count', 'answers_complete', 'assessments_complete', 'item_statuses']}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--copy-to-site', action='store_true'); parser.add_argument('--archive', action='store_true')
    args = parser.parse_args(); build(args.copy_to_site, args.archive)
