"""Keep slow in-flight requests in the shared free-tier budget until completion.

The existing workers honour this same locked state file. A request can remain
queued at the provider beyond its client-side start minute; do not forget its
input reservation while it is still in flight. This process makes no API calls.
"""
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parent


def read(path, default=None):
    try: return json.loads(path.read_text())
    except FileNotFoundError: return default


def main():
    folder = ROOT / 'provider_rate'
    folder.mkdir(exist_ok=True)
    print('Tracking in-flight input reservations; no model requests made by this process.', flush=True)
    while True:
        active = {}
        for transport in ['google', 'google_compat']:
            for path in (ROOT / 'calls' / transport).glob('*/ACTIVE.json'):
                value = read(path)
                if not value: continue
                try: os.kill(value['pid'], 0)
                except (ProcessLookupError, PermissionError): continue
                try: started = path.stat().st_mtime
                except FileNotFoundError: continue
                if time.time() - started > 360: continue
                count = read(ROOT / 'token_counts' / (value['source_request_sha256'] + '.json'))
                if count: active[path.parent.name] = count['reserved_input_tokens']
        with (folder / 'google.lock').open('a+') as handle:
            fcntl.flock(handle, fcntl.LOCK_EX)
            state = read(folder / 'google.json', {})
            tick = time.time()
            recent = [r for r in state.get('reservations', []) if r['at'] > tick - 61]
            for operation, tokens in active.items():
                matches = [r for r in recent if r['operation'] == operation]
                if matches:
                    entry = max(matches, key=lambda r: r['at'])
                    entry.setdefault('first_reserved_at', entry['at'])
                    entry.update(at=tick, tracked_in_flight=True)
                else:
                    recent.append({'at': tick, 'tokens': tokens, 'operation': operation,
                                   'tracked_in_flight': True, 'restored_active_reservation': True})
            recent.sort(key=lambda r: r['at'])
            state.update(reservations=recent, in_flight_accounting=True,
                         in_flight_operations=sorted(active), updated_at=datetime.now(timezone.utc).isoformat())
            temp = folder / 'google.inflight.tmp'
            temp.write_text(json.dumps(state, indent=2) + '\n')
            temp.replace(folder / 'google.json')
            fcntl.flock(handle, fcntl.LOCK_UN)
        time.sleep(1)


if __name__ == '__main__':
    main()
