"""One unauthenticated smoke test of the public HF-maintained Gemma Space."""
import asyncio
from datetime import datetime, timezone
import json
from pathlib import Path
import time

import httpx

ROOT = Path(__file__).resolve().parent
BASE = "https://huggingface-projects-gemma-4-31b-it.hf.space"


async def main():
    started = time.monotonic()
    payload = {
        "text": "Reply with exactly OK.", "files": None, "history": None,
        "thinking": False, "max_new_tokens": 100, "image_token_budget": 280,
        "system_prompt": "", "temperature": 0, "top_p": 1,
        "top_k": 0, "repetition_penalty": 1,
    }
    result = {
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "space": "huggingface-projects/gemma-4-31b-it", "auth": "none",
        "source_model": "google/gemma-4-31b-it", "request": payload,
        "paid_fallback": False, "events": [], "ready_for_cases": False,
    }
    try:
        async with asyncio.timeout(65):
            async with httpx.AsyncClient(timeout=httpx.Timeout(60, connect=10), trust_env=False) as client:
                response = await client.post(BASE + "/gradio_api/call/v2/chat", json=payload)
                result["http_status"] = response.status_code
                data = response.json()
                result["call_response"] = data
                if response.status_code == 200 and data.get("event_id"):
                    async with client.stream("GET", BASE + "/gradio_api/call/chat/" + data["event_id"]) as stream:
                        result["stream_http_status"] = stream.status_code
                        async for line in stream.aiter_lines():
                            if line and not line.startswith(":"):
                                result["events"].append(line)
                    result["ready_for_cases"] = any("OK" in line for line in result["events"]) and not any("event: error" in line for line in result["events"])
    except Exception as exc:
        result.update(error_type=type(exc).__name__, error=str(exc))
    result["seconds"] = round(time.monotonic() - started, 3)
    path = ROOT / ("HF_SMOKE_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + ".json")
    with path.open("x") as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    print(json.dumps({k: v for k, v in result.items() if k not in {"request", "events"}}, ensure_ascii=False), flush=True)
    print(json.dumps({"events": result["events"][-4:], "file": path.name}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    asyncio.run(main())
